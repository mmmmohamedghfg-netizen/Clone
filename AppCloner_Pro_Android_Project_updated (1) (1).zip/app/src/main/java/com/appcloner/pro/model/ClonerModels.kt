package com.appcloner.pro.model

import android.graphics.Bitmap
import org.json.JSONObject

enum class StealthLockMode(val id: String, val labelAr: String, val descAr: String) {
    NONE("none", "بدون قفل", "فتح النسخة مباشرة بدون شاشة حماية"),
    PIN_LOCK("pin_lock", "قفل برقم سري (PIN Lock)", "مطالبة المستخدم بإدخال رقم سري عند فتح النسخة"),
    BIOMETRIC("biometric", "قفل ببصمة الإصبع (Biometric)", "حماية النسخة ببصمة الإصبع أو الوجه بالإضافة للرقم السري"),
    CALCULATOR_VAULT("calculator", "تمويه الآلة الحاسبة (Calculator Vault)", "تفتح النسخة كآلة حاسبة حقيقية ولا تدخل للتطبيق إلا بعد كتابة الرقم السري ثم (=)"),
    FAKE_CRASH("fake_crash", "تمويه توقف التطبيق (Fake Crash Dialog)", "إظهار رسالة (توقف التطبيق عن العمل) ولا يفتح إلا بالضغط المطول على زر موافق")
}

enum class ProxyProtocol(val id: String, val labelAr: String) {
    SOCKS5("SOCKS5", "SOCKS5 Proxy"),
    HTTP("HTTP", "HTTP / HTTPS Proxy")
}

data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceApkPath: String,
    val splitApkPaths: List<String> = emptyList(),
    val apkSizeMb: Float,
    val isSystemApp: Boolean,
    val isExternalApkFile: Boolean = false,
    val originalSignatureSha256: String = "",
    val originalSignatureBase64: String = "",
    val iconBitmap: Bitmap?,
    val requestedPermissions: List<String>
) {
    val isSplitApp: Boolean get() = splitApkPaths.isNotEmpty()
}

data class CloneConfiguration(
    val originalPackageName: String,
    val originalAppName: String,
    val sourceApkPath: String,
    val splitApkPaths: List<String> = emptyList(),
    val originalSignatureSha256: String = "",
    val originalSignatureBase64: String = "",
    // Single or Batch Cloning
    val cloneNumber: Int = 1,
    val batchCloneCount: Int = 1, // 1..10 clones in one click
    val batchAutoColorShift: Boolean = true,
    val customCloneName: String,
    val newPackageName: String,
    // Icon customization & Adaptive/WebP handling
    val iconHueShift: Float = 140f,
    val iconRotationDegrees: Int = 0,
    val iconFlipHorizontal: Boolean = false,
    val showBadge: Boolean = true,
    val badgeText: String = "2",
    val replaceAdaptiveAndWebpIcons: Boolean = true,
    val patchArscAppLabel: Boolean = true,
    // Privacy, Identity & Signature Spoofing
    val injectDexRuntimeHook: Boolean = false, // off by default until the DEX hook is verified on a device
    val spoofOriginalSignature: Boolean = true,
    val spoofAndroidId: Boolean = true,
    val spoofImeiAndSerial: Boolean = true,
    val spoofWifiMacAddress: Boolean = true,
    val hideSimOperatorInfo: Boolean = false,
    val disableScreenshots: Boolean = false,
    val incognitoKeyboard: Boolean = true,
    // Unique device identity (each copy looks like a different phone)
    val deviceIdentitySeed: Long = 0L,
    // App Lock & Stealth Mode
    val stealthLockMode: StealthLockMode = StealthLockMode.NONE,
    val lockPinCode: String = "1234",
    // Per-Clone Proxy Routing
    val enableProxy: Boolean = false,
    val proxyProtocol: ProxyProtocol = ProxyProtocol.SOCKS5,
    val proxyHost: String = "",
    val proxyPort: String = "1080",
    val proxyUsername: String = "",
    val proxyPassword: String = "",
    // Network & Permissions
    val blockInternetAccess: Boolean = false,
    val removeCameraPermission: Boolean = false,
    val removeLocationPermission: Boolean = false,
    val removeAudioRecordPermission: Boolean = false,
    // Display & Storage
    val mergeSplitsIntoStandaloneApk: Boolean = true,
    val allowExternalStorageInstall: Boolean = true,
    val clearCacheOnExit: Boolean = false,
    val fakeLocaleLanguage: String = "default"
)

data class CloneProfile(
    val id: String,
    val profileName: String,
    val configJson: String,
    val createdAt: Long
)

data class ClonedApkRecord(
    val id: String,
    val originalAppName: String,
    val clonedAppName: String,
    val originalPackage: String,
    val clonedPackage: String,
    val cloneNumber: Int,
    val apkFilePath: String,
    val fileSizeMb: Float,
    val mergedSplitsCount: Int = 0,
    val stealthModeLabel: String = "بدون قفل",
    val deviceLabel: String = "",
    val deviceProfileJson: String = "",
    val createdAt: Long
)

/** The virtual phone identity a single cloned copy reports to the app. */
data class DeviceProfile(
    val marketName: String,
    val brand: String,
    val manufacturer: String,
    val model: String,
    val device: String,
    val product: String,
    val board: String,
    val hardware: String,
    val androidRelease: String,
    val sdkInt: Int,
    val buildId: String,
    val incremental: String,
    val securityPatch: String,
    val fingerprint: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val densityDpi: Int,
    val cpuAbi: String,
    val serial: String,
    val imei: String,
    val androidId: String,
    val wifiMac: String,
    val timezone: String,
    val carrierName: String
) {
    val label: String get() = "$marketName ($model)"

    fun toJson(): String = JSONObject().apply {
        put("market_name", marketName)
        put("brand", brand)
        put("manufacturer", manufacturer)
        put("model", model)
        put("device", device)
        put("product", product)
        put("board", board)
        put("hardware", hardware)
        put("android_release", androidRelease)
        put("sdk_int", sdkInt)
        put("build_id", buildId)
        put("incremental", incremental)
        put("security_patch", securityPatch)
        put("fingerprint", fingerprint)
        put("screen_width", screenWidth)
        put("screen_height", screenHeight)
        put("density_dpi", densityDpi)
        put("cpu_abi", cpuAbi)
        put("serial", serial)
        put("imei", imei)
        put("android_id", androidId)
        put("wifi_mac", wifiMac)
        put("timezone", timezone)
        put("carrier_name", carrierName)
    }.toString()

    companion object {
        fun fromJson(json: String): DeviceProfile? = try {
            val o = JSONObject(json)
            DeviceProfile(
                marketName = o.optString("market_name"),
                brand = o.optString("brand"),
                manufacturer = o.optString("manufacturer"),
                model = o.optString("model"),
                device = o.optString("device"),
                product = o.optString("product"),
                board = o.optString("board"),
                hardware = o.optString("hardware"),
                androidRelease = o.optString("android_release"),
                sdkInt = o.optInt("sdk_int"),
                buildId = o.optString("build_id"),
                incremental = o.optString("incremental"),
                securityPatch = o.optString("security_patch"),
                fingerprint = o.optString("fingerprint"),
                screenWidth = o.optInt("screen_width"),
                screenHeight = o.optInt("screen_height"),
                densityDpi = o.optInt("density_dpi"),
                cpuAbi = o.optString("cpu_abi"),
                serial = o.optString("serial"),
                imei = o.optString("imei"),
                androidId = o.optString("android_id"),
                wifiMac = o.optString("wifi_mac"),
                timezone = o.optString("timezone"),
                carrierName = o.optString("carrier_name")
            )
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * Snapshot of everything already taken (clone numbers, package names, device identifiers).
 * Used to make sure a new copy never collides with an existing copy.
 */
class CloneRegistry {
    val cloneNumbersByOriginal = mutableMapOf<String, MutableSet<Int>>()
    val usedPackages = mutableSetOf<String>()
    val usedDeviceIds = mutableSetOf<String>()
    val usedDeviceModels = mutableSetOf<String>()

    fun numbersFor(originalPackage: String): MutableSet<Int> =
        cloneNumbersByOriginal.getOrPut(originalPackage) { mutableSetOf() }
}

data class CloneBuildProgress(
    val isRunning: Boolean = false,
    val stepTitle: String = "",
    val progressFraction: Float = 0f,
    val logs: List<String> = emptyList(),
    val finishedApkRecords: List<ClonedApkRecord> = emptyList(),
    val errorMessage: String? = null
)
