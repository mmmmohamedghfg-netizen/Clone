package com.appcloner.pro.model

import android.graphics.Bitmap

enum class StealthLockMode(val id: String, val labelAr: String, val descAr: String) {
    NONE("none", "بدون قفل", "فتح النسخة مباشرة بدون شاشة حماية"),
    PIN_LOCK("pin_lock", "قفل برقم سري (PIN Lock)", "مطالبة المستخدم بإدخال رقم سري عند فتح النسخة"),
    BIOMETRIC("biometric", "قفل ببصمة الإصبع (Biometric)", "حماية النسخة ببصمة الإصبع أو الوجه بالإضافة للرقم السري"),
    CALCULATOR_VAULT("calculator", "تمويه الآلة الحاسبة (Calculator Vault)", "تفتح النسخة كآلة حاسبة حقيقية ولا تدخل للتطبيق إلا بعد كتابة الرقم السري ثم (=)"),
    FAKE_CRASH("fake_crash", "تمويه توقف التطبيق (Fake Crash Dialog)", "إظهار رسالة (توقف التطبيق عن العمل) ولا يفتح إلا بالضغط المطول على زر موافق")
}

enum class ProxyProtocol(val id: String, val labelAr: String) {
    SOCKS5("SOCKS5", "SOCKS5 Proxy"),
    HTTP("HTTP", "HTTP / HTTPS Proxy")
}

data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceApkPath: String,
    val splitApkPaths: List<String> = emptyList(),
    val apkSizeMb: Float,
    val isSystemApp: Boolean,
    val isExternalApkFile: Boolean = false,
    val originalSignatureSha256: String = "",
    val originalSignatureBase64: String = "",
    val iconBitmap: Bitmap?,
    val requestedPermissions: List<String>
) {
    val isSplitApp: Boolean get() = splitApkPaths.isNotEmpty()
}

data class CloneConfiguration(
    val originalPackageName: String,
    val originalAppName: String,
    val sourceApkPath: String,
    val splitApkPaths: List<String> = emptyList(),
    val originalSignatureSha256: String = "",
    val originalSignatureBase64: String = "",
    // Single or Batch Cloning
    val cloneNumber: Int = 1,
    val batchCloneCount: Int = 1, // 1..10 clones in one click
    val batchAutoColorShift: Boolean = true,
    val customCloneName: String,
    val newPackageName: String,
    // Icon customization & Adaptive/WebP handling
    val iconHueShift: Float = 140f,
    val iconRotationDegrees: Int = 0,
    val iconFlipHorizontal: Boolean = false,
    val showBadge: Boolean = true,
    val badgeText: String = "2",
    val replaceAdaptiveAndWebpIcons: Boolean = true,
    val patchArscAppLabel: Boolean = true,
    // Privacy, Identity & Signature Spoofing
    val injectDexRuntimeHook: Boolean = true,
    val spoofOriginalSignature: Boolean = true,
    val spoofAndroidId: Boolean = true,
    val spoofImeiAndSerial: Boolean = true,
    val spoofWifiMacAddress: Boolean = true,
    val hideSimOperatorInfo: Boolean = false,
    val disableScreenshots: Boolean = false,
    val incognitoKeyboard: Boolean = true,
    // App Lock & Stealth Mode
    val stealthLockMode: StealthLockMode = StealthLockMode.NONE,
    val lockPinCode: String = "1234",
    // Per-Clone Proxy Routing
    val enableProxy: Boolean = false,
    val proxyProtocol: ProxyProtocol = ProxyProtocol.SOCKS5,
    val proxyHost: String = "",
    val proxyPort: String = "1080",
    val proxyUsername: String = "",
    val proxyPassword: String = "",
    // Network & Permissions
    val blockInternetAccess: Boolean = false,
    val removeCameraPermission: Boolean = false,
    val removeLocationPermission: Boolean = false,
    val removeAudioRecordPermission: Boolean = false,
    // Display & Storage
    val mergeSplitsIntoStandaloneApk: Boolean = true,
    val allowExternalStorageInstall: Boolean = true,
    val clearCacheOnExit: Boolean = false,
    val fakeLocaleLanguage: String = "default"
)

data class CloneProfile(
    val id: String,
    val profileName: String,
    val configJson: String,
    val createdAt: Long
)

data class ClonedApkRecord(
    val id: String,
    val originalAppName: String,
    val clonedAppName: String,
    val originalPackage: String,
    val clonedPackage: String,
    val cloneNumber: Int,
    val apkFilePath: String,
    val fileSizeMb: Float,
    val mergedSplitsCount: Int = 0,
    val stealthModeLabel: String = "بدون قفل",
    val createdAt: Long
)

data class CloneBuildProgress(
    val isRunning: Boolean = false,
    val stepTitle: String = "",
    val progressFraction: Float = 0f,
    val logs: List<String> = emptyList(),
    val finishedApkRecords: List<ClonedApkRecord> = emptyList(),
    val errorMessage: String? = null
)
