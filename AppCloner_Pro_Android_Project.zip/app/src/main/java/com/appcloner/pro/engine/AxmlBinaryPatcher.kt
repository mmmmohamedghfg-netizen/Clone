package com.appcloner.pro.engine

/**
 * Low-level binary patcher for compiled Android Binary XML (AXML) files (AndroidManifest.xml)
 * and compiled resource tables (resources.arsc).
 * Preserves 100% of chunk sizes and string pool offsets while mutating package names,
 * provider authorities, app labels, permissions, and Split APK metadata.
 */
object AxmlBinaryPatcher {

    fun patchBinaryManifest(
        rawBytes: ByteArray,
        oldPackage: String,
        newPackage: String,
        oldAppLabel: String,
        newAppLabel: String,
        patchLabel: Boolean,
        neutralizeSplitFlags: Boolean,
        permissionsToDisable: List<String>
    ): ByteArray {
        var working = rawBytes.copyOf()

        // 1. Replace package name in both UTF-16LE and UTF-8 representations
        val normalizedNewPkg = normalizePackageLength(oldPackage, newPackage)
        working = replaceBinaryStringBothEncodings(working, oldPackage, normalizedNewPkg)

        // 2. Neutralize hardcoded provider authorities and permission prefixes
        val oldAuth = "$oldPackage."
        val newAuth = "$normalizedNewPkg."
        working = replaceBinaryStringBothEncodings(working, oldAuth, newAuth)

        // 3. Patch Application Label if present directly in AndroidManifest.xml string pool
        if (patchLabel && oldAppLabel.length >= 2 && newAppLabel.isNotBlank()) {
            val alignedLabel = alignLabelByteLength(oldAppLabel, newAppLabel)
            if (alignedLabel != null) {
                working = replaceBinaryStringBothEncodings(working, oldAppLabel, alignedLabel)
            }
        }

        // 4. Neutralize Split APK enforcement attributes so Merged Split APKs install as standalone APK
        if (neutralizeSplitFlags) {
            val splitMarkers = listOf(
                "isSplitRequired" to "isSplitOptional",
                "com.android.vending.splits" to "com.android.vending.merged",
                "com.android.vending.derived.apk.id" to "com.android.vending.cloned_.apk.id",
                "requiredSplitTypes" to "optionalSplitTypes"
            )
            splitMarkers.forEach { (orig, repl) ->
                if (orig.length == repl.length) {
                    working = replaceBinaryStringBothEncodings(working, orig, repl)
                }
            }
        }

        // 5. Neutralize requested permissions by mutating "android.permission.XYZ" -> "android.disabled_p.XYZ"
        permissionsToDisable.forEach { perm ->
            val neutralized = perm.replaceFirst("permission", "disabled_p")
            if (neutralized.length == perm.length) {
                working = replaceBinaryStringBothEncodings(working, perm, neutralized)
            }
        }

        return working
    }

    /**
     * Patches the compiled resources.arsc String Pool to replace the original app label
     * with the custom clone name while strictly preserving byte length and chunk alignment.
     */
    fun patchResourcesArscLabel(
        rawArscBytes: ByteArray,
        oldAppLabel: String,
        newAppLabel: String
    ): ByteArray {
        if (oldAppLabel.length < 2 || newAppLabel.isBlank() || oldAppLabel == newAppLabel) {
            return rawArscBytes
        }
        val alignedLabel = alignLabelByteLength(oldAppLabel, newAppLabel) ?: return rawArscBytes
        return replaceBinaryStringBothEncodings(rawArscBytes, oldAppLabel, alignedLabel)
    }

    /**
     * Adjusts the desired new label so its UTF-8 and UTF-16LE byte lengths match the original label,
     * allowing safe in-place binary replacement inside AXML and resources.arsc without shifting offsets.
     */
    fun alignLabelByteLength(oldLabel: String, desiredLabel: String): String? {
        val targetChars = oldLabel.length
        if (targetChars <= 0) return null

        val oldUtf8Len = oldLabel.toByteArray(Charsets.UTF_8).size
        // Build a candidate with the same character count & UTF-8 byte length
        val candidate = if (desiredLabel.length >= targetChars) {
            desiredLabel.take(targetChars)
        } else {
            desiredLabel.padEnd(targetChars, ' ')
        }

        if (candidate.toByteArray(Charsets.UTF_8).size == oldUtf8Len &&
            candidate.toByteArray(Charsets.UTF_16LE).size == oldLabel.toByteArray(Charsets.UTF_16LE).size
        ) {
            return candidate
        }

        // If multi-byte Arabic/UTF-8 characters differ in UTF-8 length, suffix the original label with clone number
        val suffix = desiredLabel.takeLastWhile { it.isDigit() || it == '#' }.ifEmpty { "2" }
        if (targetChars > suffix.length) {
            val base = oldLabel.take(targetChars - suffix.length)
            val fallback = base + suffix
            if (fallback.toByteArray(Charsets.UTF_8).size == oldUtf8Len) {
                return fallback
            }
        }
        return null
    }

    /**
     * Ensures the new package name has the exact byte length as the original package name
     * so all binary AXML chunk offsets, resource IDs, and header sizes remain 100% valid.
     */
    fun normalizePackageLength(oldPkg: String, desiredNewPkg: String): String {
        val targetLen = oldPkg.length
        if (targetLen <= 3) return oldPkg

        val chars = oldPkg.toCharArray()
        val lastDot = oldPkg.lastIndexOf('.')
        val startIdx = if (lastDot != -1 && lastDot + 1 < targetLen) lastDot + 1 else 0

        val hashSeed = desiredNewPkg.hashCode()
        val alphabet = "abcdefghijklmnopqrstuvwxyz"
        for (i in startIdx until targetLen) {
            val origChar = chars[i]
            if (origChar != '.') {
                val shift = kotlin.math.abs((hashSeed + i * 11)) % alphabet.length
                val candidate = alphabet[shift]
                chars[i] = if (candidate == origChar) alphabet[(shift + 1) % alphabet.length] else candidate
            }
        }
        return String(chars)
    }

    private fun replaceBinaryStringBothEncodings(
        data: ByteArray,
        target: String,
        replacement: String
    ): ByteArray {
        if (target.isEmpty() || target.length != replacement.length) return data
        var result = replaceBytes(
            data,
            target.toByteArray(Charsets.UTF_8),
            replacement.toByteArray(Charsets.UTF_8)
        )
        result = replaceBytes(
            result,
            target.toByteArray(Charsets.UTF_16LE),
            replacement.toByteArray(Charsets.UTF_16LE)
        )
        return result
    }

    private fun replaceBytes(source: ByteArray, pattern: ByteArray, replacement: ByteArray): ByteArray {
        if (pattern.isEmpty() || pattern.size != replacement.size || source.size < pattern.size) {
            return source
        }
        val out = source.copyOf()
        var i = 0
        while (i <= out.size - pattern.size) {
            var match = true
            for (j in pattern.indices) {
                if (out[i + j] != pattern[j]) {
                    match = false
                    break
                }
            }
            if (match) {
                System.arraycopy(replacement, 0, out, i, replacement.size)
                i += pattern.size
            } else {
                i++
            }
        }
        return out
    }
}
