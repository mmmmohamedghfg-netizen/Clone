package com.appcloner.pro.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.appcloner.pro.model.CloneBuildProgress
import com.appcloner.pro.model.CloneConfiguration
import com.appcloner.pro.model.CloneProfile
import com.appcloner.pro.model.ClonedApkRecord
import com.appcloner.pro.model.DeviceProfile
import com.appcloner.pro.model.InstalledAppInfo
import com.appcloner.pro.model.ProxyProtocol
import com.appcloner.pro.model.StealthLockMode
import com.appcloner.pro.viewmodel.ClonerViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val BgDark = Color(0xFF080D16)
private val CardDark = Color(0xFF121C2E)
private val AccentEmerald = Color(0xFF00E676)
private val AccentCyan = Color(0xFF00E5FF)
private val AccentGold = Color(0xFFFFD700)
private val AccentPurple = Color(0xFFD500F9)
private val TextPrimary = Color(0xFFF3F7FF)
private val TextSecondary = Color(0xFF8E9FBE)

@Composable
fun AppClonerScreen(viewModel: ClonerViewModel) {
    val context = LocalContext.current

    val externalApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importExternalApkUri(context, uri)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val installedApps by viewModel.installedApps.collectAsState()
        val isLoadingApps by viewModel.isLoadingApps.collectAsState()
        val searchQuery by viewModel.searchQuery.collectAsState()
        val showSystemApps by viewModel.showSystemApps.collectAsState()
        val selectedApp by viewModel.selectedApp.collectAsState()
        val cloneConfig by viewModel.cloneConfig.collectAsState()
        val previewIconBitmap by viewModel.previewIconBitmap.collectAsState()
        val buildProgress by viewModel.buildProgress.collectAsState()
        val clonedRecords by viewModel.clonedRecords.collectAsState()
        val cloneProfiles by viewModel.cloneProfiles.collectAsState()
        val devicePreview by viewModel.devicePreview.collectAsState()

        var selectedTab by remember { mutableIntStateOf(0) }
        var showSaveProfileDialog by remember { mutableStateOf(false) }

        val filteredApps = remember(installedApps, searchQuery, showSystemApps) {
            installedApps.filter { app ->
                val matchesSystem = showSystemApps || !app.isSystemApp
                val matchesSearch = searchQuery.isBlank() ||
                    app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
                matchesSystem && matchesSearch
            }
        }

        Scaffold(
            containerColor = BgDark,
            topBar = {
                TopClonerBar(
                    searchQuery = searchQuery,
                    onSearchChange = viewModel::updateSearchQuery,
                    showSystemApps = showSystemApps,
                    onToggleSystemApps = viewModel::toggleShowSystemApps,
                    onPickExternalApk = {
                        externalApkLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                    },
                    onRefresh = viewModel::refreshInstalledApps,
                    isEditingClone = selectedApp != null,
                    onBackFromEditor = viewModel::clearSelectedApp
                )
            },
            bottomBar = {
                if (selectedApp == null) {
                    NavigationBar(containerColor = CardDark) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Apps, contentDescription = "التطبيقات") },
                            label = { Text("التطبيقات المثبتة (${filteredApps.size})", fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentEmerald,
                                selectedTextColor = AccentEmerald,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = AccentEmerald.copy(alpha = 0.15f)
                            )
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = {
                                viewModel.refreshClonedHistory()
                                selectedTab = 1
                            },
                            icon = { Icon(Icons.Default.ContentCopy, contentDescription = "النسخ الجاهزة") },
                            label = { Text("النسخ المستنسخة (${clonedRecords.size})", fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentCyan,
                                selectedTextColor = AccentCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = AccentCyan.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (selectedApp != null && cloneConfig != null) {
                    CloneCustomizationWorkshop(
                        app = selectedApp!!,
                        config = cloneConfig!!,
                        previewIcon = previewIconBitmap,
                        profiles = cloneProfiles,
                        onApplyProfile = { viewModel.applyCloneProfile(context, it) },
                        onOpenSaveProfile = { showSaveProfileDialog = true },
                        onDeleteProfile = viewModel::deleteCloneProfile,
                        onUpdateConfig = viewModel::updateCloneConfig,
                        onStartClone = viewModel::startCloningProcess,
                        devicePreview = devicePreview,
                        onRegenerateIdentity = viewModel::regenerateDeviceIdentity
                    )
                } else {
                    when (selectedTab) {
                        0 -> InstalledAppsTab(
                            apps = filteredApps,
                            isLoading = isLoadingApps,
                            onSelectApp = viewModel::selectAppForCloning,
                            onPickExternalApk = {
                                externalApkLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                            }
                        )

                        1 -> ClonedHistoryTab(
                            records = clonedRecords,
                            onInstall = { viewModel.installClonedApk(context, it.apkFilePath) },
                            onShare = { viewModel.shareClonedApk(context, it) },
                            onDelete = viewModel::deleteClonedRecord
                        )
                    }
                }
            }
        }

        // Save Profile Dialog
        if (showSaveProfileDialog) {
            var newProfileName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showSaveProfileDialog = false },
                containerColor = CardDark,
                titleContentColor = TextPrimary,
                title = { Text("حفظ الإعدادات الحالية كقالب (Clone Profile)", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        label = { Text("اسم القالب (مثال: إعدادات الألعاب أو واتساب)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentEmerald,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newProfileName.isNotBlank()) {
                                viewModel.saveCurrentConfigAsProfile(context, newProfileName)
                                showSaveProfileDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = BgDark)
                    ) {
                        Text("حفظ القالب", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSaveProfileDialog = false }) {
                        Text("إلغاء", color = TextSecondary)
                    }
                }
            )
        }

        // Build Progress & Instant Install Dialog
        if (buildProgress.isRunning || buildProgress.finishedApkRecords.isNotEmpty() || buildProgress.errorMessage != null) {
            CloneBuildProgressDialog(
                progress = buildProgress,
                onInstallNow = { record ->
                    viewModel.installClonedApk(context, record.apkFilePath)
                },
                onShareNow = { record ->
                    viewModel.shareClonedApk(context, record)
                },
                onDismiss = viewModel::dismissBuildDialog
            )
        }
    }
}

@Composable
private fun TopClonerBar(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    showSystemApps: Boolean,
    onToggleSystemApps: (Boolean) -> Unit,
    onPickExternalApk: () -> Unit,
    onRefresh: () -> Unit,
    isEditingClone: Boolean,
    onBackFromEditor: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF14243D), BgDark)))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                if (isEditingClone) {
                    IconButton(onClick = onBackFromEditor) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = AccentEmerald)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(AccentEmerald, AccentCyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = BgDark)
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (isEditingClone) "ورشة الاستنساخ المتقدمة v2.0" else "App Cloner Pro v2.0",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "دمج Split APKs • حقن DEX Hook • تخطي التوقيع • قفل الآلة الحاسبة • بروكسي",
                        color = AccentCyan,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (!isEditingClone) {
                Row {
                    IconButton(onClick = onPickExternalApk) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "استنساخ ملف APK خارجي", tint = AccentGold)
                    }
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            }
        }

        if (!isEditingClone) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("ابحث باسم التطبيق أو الحزمة...", color = TextSecondary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AccentEmerald) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح", tint = TextSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CardDark,
                        unfocusedContainerColor = CardDark,
                        focusedBorderColor = AccentEmerald,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                FilterChip(
                    selected = showSystemApps,
                    onClick = { onToggleSystemApps(!showSystemApps) },
                    label = { Text("النظام", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.2f),
                        selectedLabelColor = AccentCyan,
                        labelColor = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
private fun InstalledAppsTab(
    apps: List<InstalledAppInfo>,
    isLoading: Boolean,
    onSelectApp: (InstalledAppInfo) -> Unit,
    onPickExternalApk: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Banner to pick external APK from storage
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, AccentGold.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .clickable { onPickExternalApk() },
            color = CardDark
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = AccentGold, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("استنساخ ملف APK خارجي من ذاكرة الهاتف", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("اختر أي ملف .apk من مجلد Downloads لاستنساخه بدون تثبيته أولاً", color = TextSecondary, fontSize = 11.sp)
                    }
                }
                Icon(Icons.Default.ArrowBackIosNew, contentDescription = null, tint = AccentGold, modifier = Modifier.size(16.dp))
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AccentEmerald)
                    Spacer(Modifier.height(12.dp))
                    Text("جاري فحص التطبيقات والحزم المقسمة (Split APKs)...", color = TextSecondary)
                }
            }
        } else if (apps.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد تطبيقات مطابقة للبحث", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelectApp(app) },
                        color = CardDark
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(BgDark),
                                contentAlignment = Alignment.Center
                            ) {
                                if (app.iconBitmap != null) {
                                    Image(
                                        bitmap = app.iconBitmap.asImageBitmap(),
                                        contentDescription = app.appName,
                                        modifier = Modifier.size(46.dp)
                                    )
                                } else {
                                    Icon(Icons.Default.Android, contentDescription = null, tint = AccentEmerald)
                                }
                            }

                            Spacer(Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = app.appName,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (app.isSplitApp) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "Split (${app.splitApkPaths.size + 1})",
                                            color = AccentPurple,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    if (app.isSystemApp) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "نظام",
                                            color = AccentGold,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = app.packageName,
                                    color = AccentCyan,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "الإصدار ${app.versionName} • إجمالي الحجم ${String.format("%.1f", app.apkSizeMb)} MB",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }

                            Button(
                                onClick = { onSelectApp(app) },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = BgDark),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("استنساخ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CloneCustomizationWorkshop(
    app: InstalledAppInfo,
    config: CloneConfiguration,
    previewIcon: android.graphics.Bitmap?,
    profiles: List<CloneProfile>,
    onApplyProfile: (CloneProfile) -> Unit,
    onOpenSaveProfile: () -> Unit,
    onDeleteProfile: (String) -> Unit,
    onUpdateConfig: ((CloneConfiguration) -> CloneConfiguration) -> Unit,
    onStartClone: () -> Unit,
    devicePreview: DeviceProfile?,
    onRegenerateIdentity: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Live Preview Header Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AccentEmerald.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
            color = CardDark,
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(78.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(BgDark)
                            .border(1.5.dp, AccentCyan, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (previewIcon != null) {
                            Image(
                                bitmap = previewIcon.asImageBitmap(),
                                contentDescription = "معاينة الأيقونة",
                                modifier = Modifier.size(68.dp)
                            )
                        } else {
                            Icon(Icons.Default.Android, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(44.dp))
                        }
                    }

                    Spacer(Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = config.customCloneName,
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "الحزمة الأصلية: ${config.originalPackageName}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "الحزمة الجديدة: ${config.newPackageName}",
                            color = AccentEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (app.isSplitApp) {
                            Text(
                                text = "يحتوي على ${app.splitApkPaths.size} حزم Split فرعية سيتم دمجها تلقائياً",
                                color = AccentGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                Button(
                    onClick = onStartClone,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = BgDark),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Build, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    val btnLabel = if (config.batchCloneCount > 1) {
                        "بدء الاستنساخ الجماعي (${config.batchCloneCount} نسخ دفعة واحدة)"
                    } else {
                        "بدء بناء وتوقيع النسخة المستقلة الآن (Build Clone APK)"
                    }
                    Text(
                        btnLabel,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }
        }

        // 2. Clone Profiles Bar (Quick Presets + Save Current Profile)
        SectionCard(title = "قوالب الإعدادات الجاهزة (Clone Profiles)", icon = Icons.Default.Bookmarks) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("اختر قالباً لتطبيقه فوراً أو احفظ إعداداتك:", color = TextSecondary, fontSize = 12.sp)
                TextButton(onClick = onOpenSaveProfile) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("حفظ كقالب", color = AccentEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(profiles, key = { it.id }) { prof ->
                    AssistChip(
                        onClick = { onApplyProfile(prof) },
                        label = { Text(prof.profileName, color = TextPrimary, fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentGold, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (!prof.id.startsWith("prof_")) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "حذف القالب",
                                    tint = TextSecondary,
                                    modifier = Modifier
                                        .size(15.dp)
                                        .clickable { onDeleteProfile(prof.id) }
                                )
                            }
                        },
                        border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.4f))
                    )
                }
            }
        }

        // 3. Clone Number, Batch Cloning & App Label Section
        SectionCard(title = "١. رقم النسخة، الاستنساخ الجماعي (Batch)، والاسم", icon = Icons.Default.Tag) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("رقم النسخة الأساسي (Clone Number):", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledIconButton(
                        onClick = {
                            val next = (config.cloneNumber - 1).coerceAtLeast(1)
                            onUpdateConfig {
                                it.copy(
                                    cloneNumber = next,
                                    customCloneName = "${config.originalAppName} #$next",
                                    badgeText = "$next"
                                )
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = BgDark, contentColor = AccentCyan)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "إنقاص")
                    }
                    Text(
                        text = "#${config.cloneNumber}",
                        color = AccentGold,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    FilledIconButton(
                        onClick = {
                            val next = config.cloneNumber + 1
                            onUpdateConfig {
                                it.copy(
                                    cloneNumber = next,
                                    customCloneName = "${config.originalAppName} #$next",
                                    badgeText = "$next"
                                )
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = BgDark, contentColor = AccentEmerald)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "زيادة")
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Batch Cloning Slider
            Text(
                text = "عدد النسخ المراد بناؤها دفعة واحدة (Batch Clone): ${config.batchCloneCount} نسخة",
                color = AccentCyan,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            Slider(
                value = config.batchCloneCount.toFloat(),
                onValueChange = { v -> onUpdateConfig { it.copy(batchCloneCount = v.toInt().coerceIn(1, 10)) } },
                valueRange = 1f..10f,
                steps = 8,
                colors = SliderDefaults.colors(thumbColor = AccentEmerald, activeTrackColor = AccentEmerald)
            )

            if (config.batchCloneCount > 1) {
                SwitchOptionRow(
                    title = "تلوين تلقائي مختلف لكل نسخة في الدفعة",
                    subtitle = "تغيير لون الأيقونة ورقم الشارة تلقائياً لكل نسخة (#1, #2, #3...)",
                    checked = config.batchAutoColorShift,
                    onCheckedChange = { v -> onUpdateConfig { it.copy(batchAutoColorShift = v) } }
                )
            }

            OutlinedTextField(
                value = config.customCloneName,
                onValueChange = { newName -> onUpdateConfig { it.copy(customCloneName = newName) } },
                label = { Text("اسم التطبيق الجديد على الشاشة الرئيسية") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentEmerald,
                    unfocusedBorderColor = TextSecondary,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            SwitchOptionRow(
                title = "تعديل الاسم الظاهر داخل resources.arsc و Manifest",
                subtitle = "تحديث جدول نصوص الحزمة الثنائي ليظهر الاسم الجديد تحت الأيقونة",
                checked = config.patchArscAppLabel,
                onCheckedChange = { v -> onUpdateConfig { it.copy(patchArscAppLabel = v) } }
            )
        }

        // 4. Core Engine Upgrades (Split APKs, DEX Hook, Signature Spoofing)
        SectionCard(title = "٢. محرك الاستنساخ المتقدم وتخطي الحماية (Core Engine)", icon = Icons.Default.Memory) {
            SwitchOptionRow(
                title = "حقن محرك التمويه التنفيذي (Inject Dalvik DEX Hook)",
                subtitle = "حقن ملف classesN.dex مخصص لتفعيل التمويه والقفل والبروكسي وقت التشغيل",
                checked = config.injectDexRuntimeHook,
                onCheckedChange = { v -> onUpdateConfig { it.copy(injectDexRuntimeHook = v) } }
            )

            SwitchOptionRow(
                title = "تخطي فحص التوقيع الأصلي (Signature Verification Bypass)",
                subtitle = if (config.originalSignatureSha256.isNotBlank()) {
                    "حفظ وتمرير بصمة التوقيع الأصلي (${config.originalSignatureSha256.take(17)}...)"
                } else {
                    "تمويه التوقيع الرقمي الأصلي لمنع التطبيق من اكتشاف الاستنساخ"
                },
                checked = config.spoofOriginalSignature,
                onCheckedChange = { v -> onUpdateConfig { it.copy(spoofOriginalSignature = v) } }
            )

            SwitchOptionRow(
                title = "دمج الحزم المقسمة في ملف واحد (Merge Split APKs)",
                subtitle = if (app.isSplitApp) {
                    "دمج ${app.splitApkPaths.size} ملفات Split (مكتبات .so والموارد) في APK مستقل"
                } else {
                    "تعطيل قيود App Bundle وتحويل التطبيق إلى APK موحد مستقل"
                },
                checked = config.mergeSplitsIntoStandaloneApk,
                onCheckedChange = { v -> onUpdateConfig { it.copy(mergeSplitsIntoStandaloneApk = v) } }
            )
        }

        // 5. Icon Customization Studio
        SectionCard(title = "٣. استوديو الأيقونة ودعم Adaptive / WebP Icons", icon = Icons.Default.Palette) {
            Text(
                text = "تغيير درجة لون الأيقونة (Hue Shift): ${config.iconHueShift.toInt()}°",
                color = AccentCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = config.iconHueShift,
                onValueChange = { v -> onUpdateConfig { it.copy(iconHueShift = v) } },
                valueRange = 0f..360f,
                colors = SliderDefaults.colors(thumbColor = AccentCyan, activeTrackColor = AccentCyan)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تدوير الأيقونة:", color = TextPrimary, fontSize = 13.sp)
                listOf(0, 90, 180, 270).forEach { deg ->
                    FilterChip(
                        selected = config.iconRotationDegrees == deg,
                        onClick = { onUpdateConfig { it.copy(iconRotationDegrees = deg) } },
                        label = { Text("${deg}°") }
                    )
                }
            }

            SwitchOptionRow(
                title = "استبدال الأيقونات المتكيفة وصيغ WebP (anydpi-v26 & WebP)",
                subtitle = "إجبار أندرويد 8 إلى 15 على إظهار الأيقونة الملونة والشارة بدلاً من القناع المتكيف",
                checked = config.replaceAdaptiveAndWebpIcons,
                onCheckedChange = { v -> onUpdateConfig { it.copy(replaceAdaptiveAndWebpIcons = v) } }
            )

            SwitchOptionRow(
                title = "عكس الأيقونة أفقياً (Flip Icon Horizontally)",
                subtitle = "قلب شكل الأيقونة لتمييزها بصرياً عن التطبيق الأصلي",
                checked = config.iconFlipHorizontal,
                onCheckedChange = { v -> onUpdateConfig { it.copy(iconFlipHorizontal = v) } }
            )

            SwitchOptionRow(
                title = "إضافة شارة رقمية على الأيقونة (Clone Badge)",
                subtitle = "يرسم شارة مميزة أسفل الأيقونة لتمييز رقم النسخة",
                checked = config.showBadge,
                onCheckedChange = { v -> onUpdateConfig { it.copy(showBadge = v) } }
            )

            if (config.showBadge) {
                OutlinedTextField(
                    value = config.badgeText,
                    onValueChange = { txt -> onUpdateConfig { it.copy(badgeText = txt.take(3)) } },
                    label = { Text("نص الشارة (حتى 3 أحرف/أرقام)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentGold,
                        unfocusedBorderColor = TextSecondary,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        }

        // 6. App Lock & Stealth Mode (PIN, Biometric, Calculator Vault, Fake Crash)
        SectionCard(title = "٤. قفل النسخة ووضع التمويه (Stealth & Calculator Vault)", icon = Icons.Default.Lock) {
            Text("اختر نمط حماية أو تمويه فتح النسخة:", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))

            StealthLockMode.values().forEach { mode ->
                val selected = config.stealthLockMode == mode
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(
                            width = if (selected) 1.5.dp else 0.5.dp,
                            color = if (selected) AccentEmerald else TextSecondary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onUpdateConfig { it.copy(stealthLockMode = mode) } },
                    color = BgDark
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected,
                            onClick = { onUpdateConfig { it.copy(stealthLockMode = mode) } },
                            colors = RadioButtonDefaults.colors(selectedColor = AccentEmerald)
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(mode.labelAr, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(mode.descAr, color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }

            if (config.stealthLockMode != StealthLockMode.NONE) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = config.lockPinCode,
                    onValueChange = { pin -> onUpdateConfig { it.copy(lockPinCode = pin.filter { c -> c.isDigit() }.take(8)) } },
                    label = { Text("الرقم السري للفتح / كود الآلة الحاسبة (PIN Code)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentEmerald,
                        unfocusedBorderColor = TextSecondary,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        }

        // 7. Per-Clone Proxy Routing (SOCKS5 / HTTP Proxy)
        SectionCard(title = "٥. توجيه الاتصال عبر بروكسي مستقل (SOCKS5 / HTTP Proxy)", icon = Icons.Default.VpnLock) {
            SwitchOptionRow(
                title = "تفعيل بروكسي خاص لهذه النسخة فقط",
                subtitle = "تشغيل النسخة بعنوان IP ودولة مختلفة عن باقي الهاتف",
                checked = config.enableProxy,
                onCheckedChange = { v -> onUpdateConfig { it.copy(enableProxy = v) } }
            )

            if (config.enableProxy) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProxyProtocol.values().forEach { proto ->
                        FilterChip(
                            selected = config.proxyProtocol == proto,
                            onClick = { onUpdateConfig { it.copy(proxyProtocol = proto) } },
                            label = { Text(proto.labelAr, fontSize = 12.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = config.proxyHost,
                        onValueChange = { h -> onUpdateConfig { it.copy(proxyHost = h.trim()) } },
                        label = { Text("عنوان الخادم (Host / IP)") },
                        modifier = Modifier.weight(2f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCyan,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = config.proxyPort,
                        onValueChange = { p -> onUpdateConfig { it.copy(proxyPort = p.filter { c -> c.isDigit() }.take(5)) } },
                        label = { Text("المنفذ (Port)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCyan,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = config.proxyUsername,
                        onValueChange = { u -> onUpdateConfig { it.copy(proxyUsername = u) } },
                        label = { Text("اسم المستخدم (اختياري)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCyan,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = config.proxyPassword,
                        onValueChange = { pw -> onUpdateConfig { it.copy(proxyPassword = pw) } },
                        label = { Text("كلمة المرور (اختياري)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentCyan,
                            unfocusedBorderColor = TextSecondary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            }
        }

        // 7b. Unique virtual phone identity for this copy
        SectionCard(title = "هوية جهاز مستقلة لهذه النسخة (Unique Device Identity)", icon = Icons.Default.PhoneAndroid) {
            Text(
                "كل نسخة تُبنى بهاتف افتراضي مختلف (طراز وبصمة ومعرفات فريدة) ولا تتعارض مع النسخ الأخرى.",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(8.dp))
            val device = devicePreview
            if (device == null) {
                Text("جاري توليد الهوية...", color = TextSecondary, fontSize = 12.sp)
            } else {
                IdentityRow("الطراز", "${device.marketName} (${device.model})")
                IdentityRow("الشركة المصنّعة", "${device.brand} / ${device.manufacturer}")
                IdentityRow("إصدار أندرويد", "Android ${device.androidRelease} (SDK ${device.sdkInt})")
                IdentityRow("الشاشة", "${device.screenWidth}×${device.screenHeight} • ${device.densityDpi} dpi")
                IdentityRow("المعالج", device.cpuAbi)
                IdentityRow("آخر تحديث أمني", device.securityPatch)
                IdentityRow("البصمة (Fingerprint)", device.fingerprint)
                IdentityRow("الرقم التسلسلي", device.serial)
                IdentityRow("IMEI", device.imei)
                IdentityRow("Android ID", device.androidId)
                IdentityRow("عنوان MAC", device.wifiMac)
                IdentityRow("المنطقة الزمنية", device.timezone)
                IdentityRow("مشغل الشبكة", device.carrierName)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onRegenerateIdentity,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("إعادة توليد هوية جديدة", color = AccentCyan, fontWeight = FontWeight.Bold)
            }
        }

        // 8. Privacy & Identity Spoofing Options
        SectionCard(title = "٦. الخصوصية وتمويه هوية الجهاز (Identity Spoofing)", icon = Icons.Default.Security) {
            SwitchOptionRow(
                title = "تمويه معرف أندرويد (Change Android ID)",
                subtitle = "توليد رقم Android ID عشوائي فريد لهذه النسخة لمنع التتبع والحظر",
                checked = config.spoofAndroidId,
                onCheckedChange = { v -> onUpdateConfig { it.copy(spoofAndroidId = v) } }
            )
            SwitchOptionRow(
                title = "إخفاء وتمويه رقم IMEI والرقم التسلسلي",
                subtitle = "توليد أرقام عتاد وهمية مستقلة عن هاتفك الحقيقي",
                checked = config.spoofImeiAndSerial,
                onCheckedChange = { v -> onUpdateConfig { it.copy(spoofImeiAndSerial = v) } }
            )
            SwitchOptionRow(
                title = "تمويه عنوان الـ Wi-Fi MAC Address",
                subtitle = "منع التطبيق المستنسخ من معرفة عنوان الشبكة الحقيقي",
                checked = config.spoofWifiMacAddress,
                onCheckedChange = { v -> onUpdateConfig { it.copy(spoofWifiMacAddress = v) } }
            )
            SwitchOptionRow(
                title = "إخفاء بيانات شريحة الاتصال (Hide SIM & Operator)",
                subtitle = "إخفاء كود الشبكة والدولة ومشغل الشريحة",
                checked = config.hideSimOperatorInfo,
                onCheckedChange = { v -> onUpdateConfig { it.copy(hideSimOperatorInfo = v) } }
            )
            SwitchOptionRow(
                title = "منع تصوير الشاشة (Disable Screenshots / FLAG_SECURE)",
                subtitle = "حماية نافذة النسخة من الالتقاط أو التسجيل",
                checked = config.disableScreenshots,
                onCheckedChange = { v -> onUpdateConfig { it.copy(disableScreenshots = v) } }
            )
            SwitchOptionRow(
                title = "لوحة مفاتيح خفية (Incognito Keyboard)",
                subtitle = "منع لوحة المفاتيح من حفظ الكلمات المكتوبة داخل النسخة",
                checked = config.incognitoKeyboard,
                onCheckedChange = { v -> onUpdateConfig { it.copy(incognitoKeyboard = v) } }
            )
        }

        // 9. Network, Permissions & Locale
        SectionCard(title = "٧. التحكم في الصلاحيات والإنترنت واللغة", icon = Icons.Default.GppGood) {
            SwitchOptionRow(
                title = "منع الوصول للإنترنت تماماً (Firewall / No Internet)",
                subtitle = "إبطال صلاحية android.permission.INTERNET داخل ملف AndroidManifest",
                checked = config.blockInternetAccess,
                onCheckedChange = { v -> onUpdateConfig { it.copy(blockInternetAccess = v) } }
            )
            SwitchOptionRow(
                title = "إزالة صلاحية الكاميرا (Revoke Camera)",
                subtitle = "منع النسخة من استخدام الكاميرا نهائياً",
                checked = config.removeCameraPermission,
                onCheckedChange = { v -> onUpdateConfig { it.copy(removeCameraPermission = v) } }
            )
            SwitchOptionRow(
                title = "إزالة صلاحية الموقع الجغرافي (Revoke GPS Location)",
                subtitle = "تعطيل أذونات تحديد الموقع الدقيق والتقريبي",
                checked = config.removeLocationPermission,
                onCheckedChange = { v -> onUpdateConfig { it.copy(removeLocationPermission = v) } }
            )
            SwitchOptionRow(
                title = "إزالة صلاحية الميكروفون (Revoke Audio Record)",
                subtitle = "منع النسخة من تسجيل الصوت عبر الميكروفون",
                checked = config.removeAudioRecordPermission,
                onCheckedChange = { v -> onUpdateConfig { it.copy(removeAudioRecordPermission = v) } }
            )
            SwitchOptionRow(
                title = "مسح الكاش تلقائياً عند الخروج (Clear Cache on Exit)",
                subtitle = "تفريغ الملفات المؤقتة لتوفير مساحة الهاتف",
                checked = config.clearCacheOnExit,
                onCheckedChange = { v -> onUpdateConfig { it.copy(clearCacheOnExit = v) } }
            )

            Text("تغيير لغة النسخة المستنسخة:", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "default" to "الافتراضية",
                    "ar" to "العربية",
                    "en" to "English",
                    "fr" to "Français"
                ).forEach { (code, label) ->
                    FilterChip(
                        selected = config.fakeLocaleLanguage == code,
                        onClick = { onUpdateConfig { it.copy(fakeLocaleLanguage = code) } },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardDark,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = AccentEmerald)
                Spacer(Modifier.width(8.dp))
                Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = TextSecondary.copy(alpha = 0.2f)
            )
            content()
        }
    }
}

@Composable
private fun IdentityRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            label,
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.weight(0.4f)
        )
        Text(
            value,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.6f)
        )
    }
}

@Composable
private fun SwitchOptionRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = BgDark,
                checkedTrackColor = AccentEmerald
            )
        )
    }
}

@Composable
private fun ClonedHistoryTab(
    records: List<ClonedApkRecord>,
    onInstall: (ClonedApkRecord) -> Unit,
    onShare: (ClonedApkRecord) -> Unit,
    onDelete: (ClonedApkRecord) -> Unit
) {
    if (records.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(12.dp))
                Text("لم تقم ببناء أي نسخ مستنسخة بعد", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("اختر أي تطبيق من تبويب التطبيقات المثبتة أو ملف APK خارجي لبناء ملف APK مستقل وموقّع.", color = TextSecondary, fontSize = 13.sp)
            }
        }
    } else {
        val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(records, key = { it.id }) { rec ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = CardDark,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rec.clonedAppName, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text("الحزمة المستنسخة: ${rec.clonedPackage}", color = AccentEmerald, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "الأصل: ${rec.originalAppName} • الحجم: ${String.format("%.2f", rec.fileSizeMb)} MB • الحماية: ${rec.stealthModeLabel}",
                                    color = AccentCyan,
                                    fontSize = 11.sp
                                )
                                if (rec.deviceLabel.isNotBlank()) {
                                    Text(
                                        "الجهاز الافتراضي: ${rec.deviceLabel}",
                                        color = AccentGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    "تاريخ البناء: ${dateFormat.format(Date(rec.createdAt))}" +
                                        if (rec.mergedSplitsCount > 0) " • دمج ${rec.mergedSplitsCount} Split APKs" else "",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(onClick = { onDelete(rec) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = Color(0xFFFF5252))
                            }
                        }

                        Spacer(Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onInstall(rec) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = BgDark),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("تثبيت النسخة", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onShare(rec) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("مشاركة APK", color = AccentCyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CloneBuildProgressDialog(
    progress: CloneBuildProgress,
    onInstallNow: (ClonedApkRecord) -> Unit,
    onShareNow: (ClonedApkRecord) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!progress.isRunning) onDismiss() },
        containerColor = CardDark,
        titleContentColor = TextPrimary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (progress.isRunning) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = AccentEmerald, strokeWidth = 3.dp)
                } else if (progress.errorMessage != null) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFFF5252))
                } else {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentEmerald)
                }
                Spacer(Modifier.width(10.dp))
                Text(progress.stepTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LinearProgressIndicator(
                    progress = { progress.progressFraction.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = AccentEmerald,
                    trackColor = BgDark
                )

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 220.dp),
                    color = BgDark,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(10.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        progress.logs.forEach { line ->
                            Text("• $line", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }

                progress.errorMessage?.let { err ->
                    Text(err, color = Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            if (!progress.isRunning) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    progress.finishedApkRecords.firstOrNull()?.let { firstRecord ->
                        OutlinedButton(onClick = { onShareNow(firstRecord) }) {
                            Text("مشاركة", color = AccentCyan)
                        }
                        Button(
                            onClick = { onInstallNow(firstRecord) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentEmerald, contentColor = BgDark)
                        ) {
                            Icon(Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                if (progress.finishedApkRecords.size > 1) "تثبيت الأولى (${progress.finishedApkRecords.size})" else "تثبيت الآن",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    TextButton(onClick = onDismiss) {
                        Text("إغلاق", color = TextSecondary)
                    }
                }
            }
        }
    )
}
