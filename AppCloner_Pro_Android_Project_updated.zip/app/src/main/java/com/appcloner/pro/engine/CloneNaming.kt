package com.appcloner.pro.engine

import com.appcloner.pro.model.CloneRegistry

/**
 * Naming rules that guarantee every copy has its own clone number, package name and file.
 */
object CloneNaming {

    // Package segments that are Java keywords are rejected by Android's package parser
    private val JAVA_KEYWORDS = setOf(
        "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
        "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
        "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
        "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
        "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
        "volatile", "while"
    )

    /** Next number for a new copy of [originalPackage] (one above the highest used, never reuses a number). */
    fun nextCloneNumber(originalPackage: String, registry: CloneRegistry): Int =
        (registry.numbersFor(originalPackage).maxOrNull() ?: 0) + 1

    /** First free clone number at or above [requested] for this original app. */
    fun freeCloneNumber(originalPackage: String, requested: Int, registry: CloneRegistry): Int {
        val used = registry.numbersFor(originalPackage)
        var n = requested.coerceAtLeast(1)
        while (n in used) n++
        return n
    }

    /**
     * Package name for a copy. It keeps the byte length of the original package (required for
     * binary AXML patching) and is guaranteed to differ from the original, from every copy
     * already created and from every app installed on the device.
     */
    fun freeClonePackage(
        originalPackage: String,
        cloneNumber: Int,
        registry: CloneRegistry,
        isInstalled: (String) -> Boolean
    ): String {
        for (attempt in 0 until 1000) {
            val seed = ("$originalPackage#$cloneNumber#$attempt").hashCode().toLong() * 31L + attempt
            val candidate = candidatePackage(originalPackage, seed)
            if (candidate.split('.').any { it in JAVA_KEYWORDS }) continue
            if (candidate in registry.usedPackages) continue
            if (isInstalled(candidate)) continue
            return candidate
        }
        throw IllegalStateException("تعذر إيجاد اسم حزمة فريد للنسخة #$cloneNumber")
    }

    /**
     * Replaces the last package segment with seeded random letters (every letter differs from the
     * original one). The length stays identical, so binary AXML offsets remain valid.
     * Each seed gives an independent name, so the space is 25^length rather than a few values.
     */
    private fun candidatePackage(originalPackage: String, seed: Long): String {
        val rnd = kotlin.random.Random(seed)
        val chars = originalPackage.toCharArray()
        val start = originalPackage.lastIndexOf('.') + 1
        for (i in start until chars.size) {
            var letter: Char
            do {
                letter = 'a' + rnd.nextInt(26)
            } while (letter == chars[i])
            chars[i] = letter
        }
        return String(chars)
    }
}
