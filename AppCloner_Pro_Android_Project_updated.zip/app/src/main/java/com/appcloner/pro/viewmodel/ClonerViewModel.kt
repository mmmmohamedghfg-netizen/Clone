package com.appcloner.pro.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appcloner.pro.data.ClonerRepository
import com.appcloner.pro.engine.ApkClonerEngine
import com.appcloner.pro.engine.CloneNaming
import com.appcloner.pro.engine.DeviceIdentityGenerator
import com.appcloner.pro.model.CloneBuildProgress
import com.appcloner.pro.model.CloneConfiguration
import com.appcloner.pro.model.CloneProfile
import com.appcloner.pro.model.CloneRegistry
import com.appcloner.pro.model.ClonedApkRecord
import com.appcloner.pro.model.DeviceProfile
import com.appcloner.pro.model.InstalledAppInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import kotlin.random.Random

class ClonerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ClonerRepository(application)
    private val engine = ApkClonerEngine(application)

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _showSystemApps = MutableStateFlow(false)
    val showSystemApps: StateFlow<Boolean> = _showSystemApps.asStateFlow()

    private val _selectedApp = MutableStateFlow<InstalledAppInfo?>(null)
    val selectedApp: StateFlow<InstalledAppInfo?> = _selectedApp.asStateFlow()

    private val _cloneConfig = MutableStateFlow<CloneConfiguration?>(null)
    val cloneConfig: StateFlow<CloneConfiguration?> = _cloneConfig.asStateFlow()

    private val _previewIconBitmap = MutableStateFlow<Bitmap?>(null)
    val previewIconBitmap: StateFlow<Bitmap?> = _previewIconBitmap.asStateFlow()

    private val _buildProgress = MutableStateFlow(CloneBuildProgress())
    val buildProgress: StateFlow<CloneBuildProgress> = _buildProgress.asStateFlow()

    private val _clonedRecords = MutableStateFlow<List<ClonedApkRecord>>(emptyList())
    val clonedRecords: StateFlow<List<ClonedApkRecord>> = _clonedRecords.asStateFlow()

    private val _cloneProfiles = MutableStateFlow<List<CloneProfile>>(emptyList())
    val cloneProfiles: StateFlow<List<CloneProfile>> = _cloneProfiles.asStateFlow()

    private val _devicePreview = MutableStateFlow<DeviceProfile?>(null)
    val devicePreview: StateFlow<DeviceProfile?> = _devicePreview.asStateFlow()

    init {
        refreshInstalledApps()
        refreshClonedHistory()
        refreshProfiles()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            _installedApps.value = repository.loadInstalledApps()
            _isLoadingApps.value = false
        }
    }

    fun refreshClonedHistory() {
        _clonedRecords.value = repository.getClonedRecords()
    }

    fun refreshProfiles() {
        _cloneProfiles.value = repository.getCloneProfiles()
    }

    fun updateSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun toggleShowSystemApps(show: Boolean) {
        _showSystemApps.value = show
    }

    fun selectAppForCloning(app: InstalledAppInfo) {
        _selectedApp.value = app
        val registry = repository.buildCloneRegistry()
        // Next free number: one above the highest existing copy, so numbers are never reused
        val nextNum = CloneNaming.nextCloneNumber(app.packageName, registry)

        val cleanBaseName = app.appName.removeSuffix(" (ملف خارجي)")
        val initialConfig = CloneConfiguration(
            originalPackageName = app.packageName,
            originalAppName = cleanBaseName,
            sourceApkPath = app.sourceApkPath,
            splitApkPaths = app.splitApkPaths,
            originalSignatureSha256 = app.originalSignatureSha256,
            originalSignatureBase64 = app.originalSignatureBase64,
            cloneNumber = nextNum,
            batchCloneCount = 1,
            customCloneName = "$cleanBaseName #$nextNum",
            newPackageName = previewPackage(app.packageName, nextNum, registry),
            badgeText = "$nextNum",
            deviceIdentitySeed = Random.nextLong()
        )
        _cloneConfig.value = initialConfig
        regenerateIconPreview(app.iconBitmap, initialConfig)
        refreshDevicePreview(initialConfig, registry)
    }

    fun importExternalApkUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val parsed = repository.parseExternalApkUri(uri)
            _isLoadingApps.value = false
            parsed.fold(
                onSuccess = { appInfo ->
                    Toast.makeText(context, "تم استيراد ملف APK: ${appInfo.appName}", Toast.LENGTH_SHORT).show()
                    selectAppForCloning(appInfo)
                },
                onFailure = { err ->
                    Toast.makeText(context, "خطأ في قراءة ملف APK: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    fun clearSelectedApp() {
        _selectedApp.value = null
        _cloneConfig.value = null
        _previewIconBitmap.value = null
    }

    fun updateCloneConfig(transform: (CloneConfiguration) -> CloneConfiguration) {
        val current = _cloneConfig.value ?: return
        val updated = transform(current)
        val registry = repository.buildCloneRegistry()
        val finalConfig = updated.copy(
            newPackageName = previewPackage(updated.originalPackageName, updated.cloneNumber, registry)
        )
        _cloneConfig.value = finalConfig
        regenerateIconPreview(_selectedApp.value?.iconBitmap, finalConfig)
        refreshDevicePreview(finalConfig, registry)
    }

    /** Gives the selected copy a new random virtual phone identity. */
    fun regenerateDeviceIdentity() {
        updateCloneConfig { it.copy(deviceIdentitySeed = Random.nextLong()) }
    }

    private fun previewPackage(originalPackage: String, cloneNumber: Int, registry: CloneRegistry): String =
        try {
            CloneNaming.freeClonePackage(originalPackage, cloneNumber, registry) { pkg ->
                engine.isPackageInstalled(pkg)
            }
        } catch (_: IllegalStateException) {
            originalPackage
        }

    private fun refreshDevicePreview(config: CloneConfiguration, registry: CloneRegistry) {
        _devicePreview.value = DeviceIdentityGenerator.generate(
            seed = config.deviceIdentitySeed,
            usedIds = registry.usedDeviceIds,
            usedModels = registry.usedDeviceModels
        )
    }

    fun saveCurrentConfigAsProfile(context: Context, profileName: String) {
        val cfg = _cloneConfig.value ?: return
        if (profileName.isBlank()) return
        repository.saveCloneProfile(profileName, cfg)
        refreshProfiles()
        Toast.makeText(context, "تم حفظ القالب ($profileName) بنجاح", Toast.LENGTH_SHORT).show()
    }

    fun applyCloneProfile(context: Context, profile: CloneProfile) {
        val current = _cloneConfig.value ?: return
        val updated = repository.applyProfileToConfig(profile, current)
        _cloneConfig.value = updated
        regenerateIconPreview(_selectedApp.value?.iconBitmap, updated)
        Toast.makeText(context, "تم تطبيق القالب: ${profile.profileName}", Toast.LENGTH_SHORT).show()
    }

    fun deleteCloneProfile(profileId: String) {
        repository.deleteCloneProfile(profileId)
        refreshProfiles()
    }

    private fun regenerateIconPreview(sourceIcon: Bitmap?, config: CloneConfiguration) {
        if (sourceIcon == null) {
            _previewIconBitmap.value = null
            return
        }
        _previewIconBitmap.value = engine.transformIconBitmap(
            source = sourceIcon,
            hueShiftDegrees = config.iconHueShift,
            rotationDegrees = config.iconRotationDegrees,
            flipHorizontal = config.iconFlipHorizontal,
            showBadge = config.showBadge,
            badgeText = config.badgeText
        )
    }

    fun startCloningProcess() {
        val config = _cloneConfig.value ?: return
        val app = _selectedApp.value ?: return
        if (_buildProgress.value.isRunning) return

        viewModelScope.launch {
            val logsList = mutableListOf<String>()
            val batchLabel = if (config.batchCloneCount > 1) " (${config.batchCloneCount} نسخ دفعة واحدة)" else ""
            _buildProgress.value = CloneBuildProgress(
                isRunning = true,
                stepTitle = "بدء عملية الاستنساخ$batchLabel...",
                progressFraction = 0.05f,
                logs = listOf("تجهيز استنساخ ${app.appName} (${app.packageName})$batchLabel...")
            )

            val result = engine.buildBatchClonedApks(
                baseConfig = config,
                sourceIcon = app.iconBitmap,
                registry = repository.buildCloneRegistry(),
                onProgress = { step, fraction, logLine ->
                    logsList.add(logLine)
                    _buildProgress.value = CloneBuildProgress(
                        isRunning = true,
                        stepTitle = step,
                        progressFraction = fraction,
                        logs = logsList.toList()
                    )
                }
            )

            result.fold(
                onSuccess = { records ->
                    records.forEach { repository.saveClonedRecord(it) }
                    refreshClonedHistory()
                    // Prepare the next copy: next free number and a fresh identity, so it never repeats this one
                    _cloneConfig.value?.let { current ->
                        val reg = repository.buildCloneRegistry()
                        val nextNum = CloneNaming.nextCloneNumber(current.originalPackageName, reg)
                        val next = current.copy(
                            cloneNumber = nextNum,
                            customCloneName = "${current.originalAppName} #$nextNum",
                            badgeText = "$nextNum",
                            newPackageName = previewPackage(current.originalPackageName, nextNum, reg),
                            deviceIdentitySeed = Random.nextLong()
                        )
                        _cloneConfig.value = next
                        refreshDevicePreview(next, reg)
                    }
                    _buildProgress.value = CloneBuildProgress(
                        isRunning = false,
                        stepTitle = "تم بناء وتوقيع ${records.size} نسخة بنجاح!",
                        progressFraction = 1.0f,
                        logs = logsList.toList(),
                        finishedApkRecords = records
                    )
                },
                onFailure = { error ->
                    logsList.add("خطأ: ${error.localizedMessage}")
                    _buildProgress.value = CloneBuildProgress(
                        isRunning = false,
                        stepTitle = "فشلت عملية الاستنساخ",
                        progressFraction = 0f,
                        logs = logsList.toList(),
                        errorMessage = error.localizedMessage ?: "حدث خطأ غير متوقع أثناء بناء الـ APK"
                    )
                }
            )
        }
    }

    fun dismissBuildDialog() {
        _buildProgress.value = CloneBuildProgress()
    }

    fun installClonedApk(context: Context, apkPath: String) {
        val file = File(apkPath)
        if (!file.exists()) {
            Toast.makeText(context, "ملف الـ APK غير موجود", Toast.LENGTH_SHORT).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !context.packageManager.canRequestPackageInstalls()
        ) {
            Toast.makeText(
                context,
                "يرجى السماح بتثبيت التطبيقات من هذا المصدر أولاً",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        }

        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر فتح مثبت الحزم: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    fun shareClonedApk(context: Context, record: ClonedApkRecord) {
        val file = File(record.apkFilePath)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, record.clonedAppName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                Intent.createChooser(shareIntent, "مشاركة ملف الـ APK المستنسخ").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة ملف APK", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteClonedRecord(record: ClonedApkRecord) {
        repository.deleteClonedRecord(record)
        refreshClonedHistory()
    }
}
