package com.appcloner.pro.engine

import com.appcloner.pro.model.DeviceProfile
import kotlin.random.Random

/**
 * Generates a consistent, virtual "phone" identity for each cloned copy.
 *
 * Everything is derived from a seed, so the preview shown in the UI matches the
 * identity that is actually written into the built APK. Identifiers (serial, IMEI,
 * Android ID, MAC) and device models are checked against the registry so that two
 * copies never share the same identity.
 */
object DeviceIdentityGenerator {

    private data class DeviceTemplate(
        val marketName: String,
        val brand: String,
        val manufacturer: String,
        val model: String,
        val device: String,
        val product: String,
        val board: String,
        val hardware: String,
        val release: String,
        val sdkInt: Int,
        val buildPrefix: String,
        val incrementalPrefix: String,
        val width: Int,
        val height: Int,
        val dpi: Int,
        val abi: String
    )

    // Real retail devices. Each copy picks a model that is not already used by another copy.
    private val CATALOG = listOf(
        DeviceTemplate(
            marketName = "Samsung Galaxy S23 Ultra", brand = "samsung", manufacturer = "samsung",
            model = "SM-S918B", device = "dm3q", product = "dm3qxxx", board = "kalama", hardware = "qcom",
            release = "14", sdkInt = 34, buildPrefix = "UP1A", incrementalPrefix = "S918BXXU",
            width = 1440, height = 3088, dpi = 600, abi = "arm64-v8a"
        ),
        DeviceTemplate(
            marketName = "Samsung Galaxy A54 5G", brand = "samsung", manufacturer = "samsung",
            model = "SM-A546B", device = "a54x", product = "a54xxx", board = "s5e8895", hardware = "exynos",
            release = "14", sdkInt = 34, buildPrefix = "UP1A", incrementalPrefix = "A546BXXU",
            width = 1080, height = 2340, dpi = 420, abi = "arm64-v8a"
        ),
        DeviceTemplate(
            marketName = "Google Pixel 7", brand = "google", manufacturer = "Google",
            model = "Pixel 7", device = "panther", product = "panther", board = "panther", hardware = "panther",
            release = "14", sdkInt = 34, buildPrefix = "UQ1A", incrementalPrefix = "",
            width = 1080, height = 2400, dpi = 420, abi = "arm64-v8a"
        ),
        DeviceTemplate(
            marketName = "Google Pixel 6a", brand = "google", manufacturer = "Google",
            model = "Pixel 6a", device = "bluejay", product = "bluejay", board = "bluejay", hardware = "bluejay",
            release = "14", sdkInt = 34, buildPrefix = "UQ1A", incrementalPrefix = "",
            width = 1080, height = 2400, dpi = 420, abi = "arm64-v8a"
        ),
        DeviceTemplate(
            marketName = "Xiaomi 13", brand = "Xiaomi", manufacturer = "Xiaomi",
            model = "2211133C", device = "fuxi", product = "fuxi", board = "kalama", hardware = "qcom",
            release = "13", sdkInt = 33, buildPrefix = "TKQ1", incrementalPrefix = "V14.0.",
            width = 1080, height = 2400, dpi = 440, abi = "arm64-v8a"
        )
    )

    // (timezone, carrier) pairs so the carrier matches the timezone of the phone
    private val LOCALE_CARRIERS = listOf(
        "Africa/Cairo" to "Vodafone EG",
        "Africa/Cairo" to "Orange EG",
        "Africa/Cairo" to "Etisalat EG",
        "Africa/Cairo" to "WE",
        "Asia/Riyadh" to "STC",
        "Asia/Dubai" to "du"
    )

    private const val ALNUM = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789"
    private const val HEX = "0123456789abcdef"
    private const val GOLDEN_MIX = -7046029254386353131L
    private const val LCG_MUL = 6364136223846793005L
    private const val LCG_ADD = 1442695040888963407L

    /** Seed for the i-th copy of a batch, so copies built together are all different phones. */
    fun seedForClone(baseSeed: Long, index: Int): Long = baseSeed + index.toLong() * GOLDEN_MIX

    /**
     * Returns a device identity whose serial/IMEI/Android ID/MAC are not in [usedIds]
     * and whose model is preferably not in [usedModels].
     */
    fun generate(seed: Long, usedIds: Set<String>, usedModels: Set<String>): DeviceProfile {
        var current = seed
        repeat(10_000) {
            val candidate = build(current, usedModels)
            val ids = listOf(candidate.serial, candidate.imei, candidate.androidId, candidate.wifiMac)
            if (ids.none { it in usedIds }) return candidate
            current = current * LCG_MUL + LCG_ADD
        }
        return build(current, usedModels)
    }

    private fun build(seed: Long, usedModels: Set<String>): DeviceProfile {
        val rnd = Random(seed)

        val start = rnd.nextInt(CATALOG.size)
        val tpl = (0 until CATALOG.size)
            .map { CATALOG[(start + it) % CATALOG.size] }
            .firstOrNull { it.model !in usedModels }
            ?: CATALOG[start]

        val incremental = if (tpl.incrementalPrefix.isEmpty()) {
            rnd.nextInt(10_000_000, 99_999_999).toString()
        } else {
            tpl.incrementalPrefix + randomString(rnd, ALNUM, 5)
        }
        val buildId = "%s.%06d.%03d".format(tpl.buildPrefix, rnd.nextInt(230101, 240601), rnd.nextInt(1, 999))
        val securityPatch = "2024-%02d-05".format(rnd.nextInt(1, 7))
        val fingerprint = "${tpl.brand}/${tpl.product}/${tpl.device}:${tpl.release}/$buildId/$incremental:user/release-keys"

        val mac = (0 until 6).joinToString(":") { i ->
            val b = rnd.nextInt(256)
            // Locally-administered unicast address (bit 1 set, bit 0 clear) like real randomized MACs
            "%02X".format(if (i == 0) (b and 0xFE) or 0x02 else b)
        }

        val (timezone, carrier) = LOCALE_CARRIERS[rnd.nextInt(LOCALE_CARRIERS.size)]

        return DeviceProfile(
            marketName = tpl.marketName,
            brand = tpl.brand,
            manufacturer = tpl.manufacturer,
            model = tpl.model,
            device = tpl.device,
            product = tpl.product,
            board = tpl.board,
            hardware = tpl.hardware,
            androidRelease = tpl.release,
            sdkInt = tpl.sdkInt,
            buildId = buildId,
            incremental = incremental,
            securityPatch = securityPatch,
            fingerprint = fingerprint,
            screenWidth = tpl.width,
            screenHeight = tpl.height,
            densityDpi = tpl.dpi,
            cpuAbi = tpl.abi,
            serial = randomString(rnd, ALNUM, 11),
            imei = luhnImei(rnd),
            androidId = randomString(rnd, HEX, 16),
            wifiMac = mac,
            timezone = timezone,
            carrierName = carrier
        )
    }

    private fun randomString(rnd: Random, alphabet: String, length: Int): String =
        (1..length).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")

    /** 15-digit IMEI starting with "35" and a valid Luhn check digit. */
    private fun luhnImei(rnd: Random): String {
        val body = "35" + (0 until 12).map { rnd.nextInt(10) }.joinToString("")
        var sum = 0
        for (i in body.indices) {
            var digit = body[body.length - 1 - i] - '0'
            if (i % 2 == 0) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
        }
        return body + ((10 - sum % 10) % 10).toString()
    }
}
