package com.appcloner.pro.data

import android.content.ContentValues
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.util.Base64
import com.appcloner.pro.model.CloneConfiguration
import com.appcloner.pro.model.CloneProfile
import com.appcloner.pro.model.CloneRegistry
import com.appcloner.pro.model.ClonedApkRecord
import com.appcloner.pro.model.DeviceProfile
import com.appcloner.pro.model.InstalledAppInfo
import com.appcloner.pro.model.ProxyProtocol
import com.appcloner.pro.model.StealthLockMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

class ClonerDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "app_cloner_pro.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS cloned_apks (
                id TEXT PRIMARY KEY,
                original_app_name TEXT NOT NULL,
                cloned_app_name TEXT NOT NULL,
                original_package TEXT NOT NULL,
                cloned_package TEXT NOT NULL,
                clone_number INTEGER NOT NULL,
                apk_file_path TEXT NOT NULL,
                file_size_mb REAL NOT NULL,
                merged_splits_count INTEGER NOT NULL DEFAULT 0,
                stealth_mode_label TEXT NOT NULL DEFAULT 'بدون قفل',
                device_label TEXT NOT NULL DEFAULT '',
                device_profile_json TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS clone_profiles (
                id TEXT PRIMARY KEY,
                profile_name TEXT NOT NULL,
                config_json TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        seedDefaultProfiles(db)
    }

    private fun seedDefaultProfiles(db: SQLiteDatabase) {
        val now = System.currentTimeMillis()
        val presets = listOf(
            Triple(
                "prof_stealth_max",
                "وضع التخفي القصوى وتخطي الحظر",
                JSONObject().apply {
                    put("spoofOriginalSignature", true)
                    put("spoofAndroidId", true)
                    put("spoofImeiAndSerial", true)
                    put("spoofWifiMacAddress", true)
                    put("hideSimOperatorInfo", true)
                    put("disableScreenshots", true)
                    put("incognitoKeyboard", true)
                    put("stealthLockMode", StealthLockMode.CALCULATOR_VAULT.name)
                }.toString()
            ),
            Triple(
                "prof_multi_social",
                "وضع تعدد الحسابات السريع (سوشيال)",
                JSONObject().apply {
                    put("spoofOriginalSignature", true)
                    put("spoofAndroidId", true)
                    put("showBadge", true)
                    put("replaceAdaptiveAndWebpIcons", true)
                    put("patchArscAppLabel", true)
                    put("mergeSplitsIntoStandaloneApk", true)
                }.toString()
            ),
            Triple(
                "prof_offline_sandbox",
                "وضع العزل بدون إنترنت وكاميرا",
                JSONObject().apply {
                    put("blockInternetAccess", true)
                    put("removeCameraPermission", true)
                    put("removeLocationPermission", true)
                    put("removeAudioRecordPermission", true)
                    put("clearCacheOnExit", true)
                }.toString()
            )
        )

        presets.forEach { (id, name, json) ->
            val cv = ContentValues().apply {
                put("id", id)
                put("profile_name", name)
                put("config_json", json)
                put("created_at", now)
            }
            db.insertWithOnConflict("clone_profiles", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    // Upgrades must keep the user's clone history: never drop tables here, only add what is missing.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db) // CREATE ... IF NOT EXISTS: only creates tables that are missing
        addColumnIfMissing(db, "cloned_apks", "device_label", "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, "cloned_apks", "device_profile_json", "TEXT NOT NULL DEFAULT ''")
    }

    private fun addColumnIfMissing(db: SQLiteDatabase, table: String, column: String, definition: String) {
        val exists = db.rawQuery("PRAGMA table_info($table)", null).use { c ->
            val nameIdx = c.getColumnIndex("name")
            var found = false
            while (c.moveToNext()) {
                if (c.getString(nameIdx) == column) found = true
            }
            found
        }
        if (!exists) {
            db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
        }
    }
}

class ClonerRepository(private val context: Context) {

    private val dbHelper = ClonerDatabaseHelper(context)

    suspend fun loadInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val sigFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            PackageManager.GET_SIGNATURES
        }
        val flags = PackageManager.GET_PERMISSIONS or sigFlag

        val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }

        val result = mutableListOf<InstalledAppInfo>()

        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val sourceDir = appInfo.sourceDir ?: continue
            val apkFile = File(sourceDir)
            if (!apkFile.exists()) continue

            if (pkg.packageName == context.packageName) continue

            val appName = try {
                pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() } ?: pkg.packageName
            } catch (_: Exception) {
                pkg.packageName
            }

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

            val iconBmp = try {
                drawableToBitmap(pm.getApplicationIcon(appInfo), 144)
            } catch (_: Exception) {
                null
            }

            val versionName = pkg.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkg.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkg.versionCode.toLong()
            }

            // Read Split APKs if installed as App Bundle
            val splitPaths = appInfo.splitSourceDirs?.filter { File(it).exists() } ?: emptyList()
            val totalBytes = apkFile.length() + splitPaths.sumOf { File(it).length() }
            val sizeMb = totalBytes.toFloat() / (1024f * 1024f)

            val (sigSha256, sigBase64) = extractSignatureInfo(pkg)
            val perms = pkg.requestedPermissions?.toList() ?: emptyList()

            result.add(
                InstalledAppInfo(
                    appName = appName,
                    packageName = pkg.packageName,
                    versionName = versionName,
                    versionCode = versionCode,
                    sourceApkPath = sourceDir,
                    splitApkPaths = splitPaths,
                    apkSizeMb = sizeMb,
                    isSystemApp = isSystem,
                    isExternalApkFile = false,
                    originalSignatureSha256 = sigSha256,
                    originalSignatureBase64 = sigBase64,
                    iconBitmap = iconBmp,
                    requestedPermissions = perms
                )
            )
        }

        result.sortedWith(compareBy<InstalledAppInfo> { it.isSystemApp }.thenBy { it.appName.lowercase() })
    }

    /**
     * Parses an external uninstalled .apk file selected from device storage (Downloads, SD Card, etc.)
     */
    suspend fun parseExternalApkUri(uri: Uri): Result<InstalledAppInfo> = withContext(Dispatchers.IO) {
        try {
            val externalCacheDir = File(context.cacheDir, "external_picked_apks").apply { mkdirs() }
            val tempApkFile = File(externalCacheDir, "picked_${System.currentTimeMillis()}.apk")

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempApkFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalArgumentException("تعذر قراءة ملف الـ APK المختار"))

            val pm = context.packageManager
            @Suppress("DEPRECATION")
            val sigFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageManager.GET_SIGNING_CERTIFICATES
            } else {
                PackageManager.GET_SIGNATURES
            }
            val flags = PackageManager.GET_PERMISSIONS or sigFlag

            val pkgInfo: PackageInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(tempApkFile.absolutePath, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(tempApkFile.absolutePath, flags)
            }

            if (pkgInfo == null) {
                return@withContext Result.failure(IllegalArgumentException("ملف الـ APK غير صالح أو تالف"))
            }

            val appInfo = pkgInfo.applicationInfo
            appInfo?.sourceDir = tempApkFile.absolutePath
            appInfo?.publicSourceDir = tempApkFile.absolutePath

            val appName = try {
                if (appInfo != null) pm.getApplicationLabel(appInfo).toString() else pkgInfo.packageName
            } catch (_: Exception) {
                pkgInfo.packageName
            }

            val iconBmp = try {
                if (appInfo != null) drawableToBitmap(pm.getApplicationIcon(appInfo), 144) else null
            } catch (_: Exception) {
                null
            }

            val versionName = pkgInfo.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }

            val (sigSha256, sigBase64) = extractSignatureInfo(pkgInfo)
            val sizeMb = tempApkFile.length().toFloat() / (1024f * 1024f)

            Result.success(
                InstalledAppInfo(
                    appName = "$appName (ملف خارجي)",
                    packageName = pkgInfo.packageName,
                    versionName = versionName,
                    versionCode = versionCode,
                    sourceApkPath = tempApkFile.absolutePath,
                    splitApkPaths = emptyList(),
                    apkSizeMb = sizeMb,
                    isSystemApp = false,
                    isExternalApkFile = true,
                    originalSignatureSha256 = sigSha256,
                    originalSignatureBase64 = sigBase64,
                    iconBitmap = iconBmp,
                    requestedPermissions = pkgInfo.requestedPermissions?.toList() ?: emptyList()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractSignatureInfo(pkg: PackageInfo): Pair<String, String> {
        return try {
            val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkg.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
                    ?: pkg.signingInfo?.signingCertificateHistory?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                pkg.signatures?.firstOrNull()?.toByteArray()
            }
            if (sigBytes != null) {
                val sha256 = MessageDigest.getInstance("SHA-256")
                    .digest(sigBytes)
                    .joinToString(":") { "%02X".format(it) }
                val b64 = Base64.encodeToString(sigBytes, Base64.NO_WRAP)
                sha256 to b64
            } else {
                "" to ""
            }
        } catch (_: Exception) {
            "" to ""
        }
    }

    private fun drawableToBitmap(drawable: Drawable, maxPx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return Bitmap.createScaledBitmap(drawable.bitmap, maxPx, maxPx, true)
        }
        val bmp = Bitmap.createBitmap(maxPx, maxPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bmp
    }

    fun saveClonedRecord(record: ClonedApkRecord) {
        val cv = ContentValues().apply {
            put("id", record.id)
            put("original_app_name", record.originalAppName)
            put("cloned_app_name", record.clonedAppName)
            put("original_package", record.originalPackage)
            put("cloned_package", record.clonedPackage)
            put("clone_number", record.cloneNumber)
            put("apk_file_path", record.apkFilePath)
            put("file_size_mb", record.fileSizeMb)
            put("merged_splits_count", record.mergedSplitsCount)
            put("stealth_mode_label", record.stealthModeLabel)
            put("device_label", record.deviceLabel)
            put("device_profile_json", record.deviceProfileJson)
            put("created_at", record.createdAt)
        }
        dbHelper.writableDatabase.insertWithOnConflict("cloned_apks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getClonedRecords(): List<ClonedApkRecord> {
        val list = mutableListOf<ClonedApkRecord>()
        dbHelper.readableDatabase.rawQuery(
            "SELECT id, original_app_name, cloned_app_name, original_package, cloned_package, clone_number, apk_file_path, file_size_mb, merged_splits_count, stealth_mode_label, created_at, device_label, device_profile_json FROM cloned_apks ORDER BY created_at DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val path = c.getString(6)
                if (File(path).exists()) {
                    list.add(
                        ClonedApkRecord(
                            id = c.getString(0),
                            originalAppName = c.getString(1),
                            clonedAppName = c.getString(2),
                            originalPackage = c.getString(3),
                            clonedPackage = c.getString(4),
                            cloneNumber = c.getInt(5),
                            apkFilePath = path,
                            fileSizeMb = c.getFloat(7),
                            mergedSplitsCount = c.getInt(8),
                            stealthModeLabel = c.getString(9),
                            deviceLabel = c.getString(11) ?: "",
                            deviceProfileJson = c.getString(12) ?: "",
                            createdAt = c.getLong(10)
                        )
                    )
                }
            }
        }
        return list
    }

    /**
     * Everything already taken by existing copies, so new copies never collide with them.
     */
    fun buildCloneRegistry(): CloneRegistry {
        val registry = CloneRegistry()
        dbHelper.readableDatabase.rawQuery(
            "SELECT original_package, clone_number, cloned_package, device_profile_json FROM cloned_apks",
            null
        ).use { c ->
            while (c.moveToNext()) {
                registry.numbersFor(c.getString(0)).add(c.getInt(1))
                registry.usedPackages.add(c.getString(2))
                DeviceProfile.fromJson(c.getString(3) ?: "")?.let { dev ->
                    registry.usedDeviceIds.addAll(listOf(dev.serial, dev.imei, dev.androidId, dev.wifiMac))
                    registry.usedDeviceModels.add(dev.model)
                }
            }
        }
        return registry
    }

    fun deleteClonedRecord(record: ClonedApkRecord) {
        try {
            File(record.apkFilePath).delete()
        } catch (_: Exception) {
        }
        dbHelper.writableDatabase.delete("cloned_apks", "id = ?", arrayOf(record.id))
    }

    // Clone Profiles Management
    fun getCloneProfiles(): List<CloneProfile> {
        val list = mutableListOf<CloneProfile>()
        dbHelper.readableDatabase.rawQuery(
            "SELECT id, profile_name, config_json, created_at FROM clone_profiles ORDER BY created_at ASC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    CloneProfile(
                        id = c.getString(0),
                        profileName = c.getString(1),
                        configJson = c.getString(2),
                        createdAt = c.getLong(3)
                    )
                )
            }
        }
        return list
    }

    fun saveCloneProfile(name: String, config: CloneConfiguration) {
        val json = JSONObject().apply {
            put("iconHueShift", config.iconHueShift.toDouble())
            put("iconRotationDegrees", config.iconRotationDegrees)
            put("iconFlipHorizontal", config.iconFlipHorizontal)
            put("showBadge", config.showBadge)
            put("replaceAdaptiveAndWebpIcons", config.replaceAdaptiveAndWebpIcons)
            put("patchArscAppLabel", config.patchArscAppLabel)
            put("injectDexRuntimeHook", config.injectDexRuntimeHook)
            put("spoofOriginalSignature", config.spoofOriginalSignature)
            put("spoofAndroidId", config.spoofAndroidId)
            put("spoofImeiAndSerial", config.spoofImeiAndSerial)
            put("spoofWifiMacAddress", config.spoofWifiMacAddress)
            put("hideSimOperatorInfo", config.hideSimOperatorInfo)
            put("disableScreenshots", config.disableScreenshots)
            put("incognitoKeyboard", config.incognitoKeyboard)
            put("stealthLockMode", config.stealthLockMode.name)
            put("lockPinCode", config.lockPinCode)
            put("enableProxy", config.enableProxy)
            put("proxyProtocol", config.proxyProtocol.name)
            put("proxyHost", config.proxyHost)
            put("proxyPort", config.proxyPort)
            put("blockInternetAccess", config.blockInternetAccess)
            put("removeCameraPermission", config.removeCameraPermission)
            put("removeLocationPermission", config.removeLocationPermission)
            put("removeAudioRecordPermission", config.removeAudioRecordPermission)
            put("mergeSplitsIntoStandaloneApk", config.mergeSplitsIntoStandaloneApk)
            put("clearCacheOnExit", config.clearCacheOnExit)
            put("fakeLocaleLanguage", config.fakeLocaleLanguage)
        }.toString()

        val cv = ContentValues().apply {
            put("id", UUID.randomUUID().toString())
            put("profile_name", name.trim())
            put("config_json", json)
            put("created_at", System.currentTimeMillis())
        }
        dbHelper.writableDatabase.insertWithOnConflict("clone_profiles", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun applyProfileToConfig(profile: CloneProfile, current: CloneConfiguration): CloneConfiguration {
        return try {
            val obj = JSONObject(profile.configJson)
            current.copy(
                iconHueShift = obj.optDouble("iconHueShift", current.iconHueShift.toDouble()).toFloat(),
                iconRotationDegrees = obj.optInt("iconRotationDegrees", current.iconRotationDegrees),
                iconFlipHorizontal = obj.optBoolean("iconFlipHorizontal", current.iconFlipHorizontal),
                showBadge = obj.optBoolean("showBadge", current.showBadge),
                replaceAdaptiveAndWebpIcons = obj.optBoolean("replaceAdaptiveAndWebpIcons", current.replaceAdaptiveAndWebpIcons),
                patchArscAppLabel = obj.optBoolean("patchArscAppLabel", current.patchArscAppLabel),
                injectDexRuntimeHook = obj.optBoolean("injectDexRuntimeHook", current.injectDexRuntimeHook),
                spoofOriginalSignature = obj.optBoolean("spoofOriginalSignature", current.spoofOriginalSignature),
                spoofAndroidId = obj.optBoolean("spoofAndroidId", current.spoofAndroidId),
                spoofImeiAndSerial = obj.optBoolean("spoofImeiAndSerial", current.spoofImeiAndSerial),
                spoofWifiMacAddress = obj.optBoolean("spoofWifiMacAddress", current.spoofWifiMacAddress),
                hideSimOperatorInfo = obj.optBoolean("hideSimOperatorInfo", current.hideSimOperatorInfo),
                disableScreenshots = obj.optBoolean("disableScreenshots", current.disableScreenshots),
                incognitoKeyboard = obj.optBoolean("incognitoKeyboard", current.incognitoKeyboard),
                stealthLockMode = runCatching {
                    StealthLockMode.valueOf(obj.optString("stealthLockMode", current.stealthLockMode.name))
                }.getOrDefault(current.stealthLockMode),
                lockPinCode = obj.optString("lockPinCode", current.lockPinCode),
                enableProxy = obj.optBoolean("enableProxy", current.enableProxy),
                proxyProtocol = runCatching {
                    ProxyProtocol.valueOf(obj.optString("proxyProtocol", current.proxyProtocol.name))
                }.getOrDefault(current.proxyProtocol),
                proxyHost = obj.optString("proxyHost", current.proxyHost),
                proxyPort = obj.optString("proxyPort", current.proxyPort),
                blockInternetAccess = obj.optBoolean("blockInternetAccess", current.blockInternetAccess),
                removeCameraPermission = obj.optBoolean("removeCameraPermission", current.removeCameraPermission),
                removeLocationPermission = obj.optBoolean("removeLocationPermission", current.removeLocationPermission),
                removeAudioRecordPermission = obj.optBoolean("removeAudioRecordPermission", current.removeAudioRecordPermission),
                mergeSplitsIntoStandaloneApk = obj.optBoolean("mergeSplitsIntoStandaloneApk", current.mergeSplitsIntoStandaloneApk),
                clearCacheOnExit = obj.optBoolean("clearCacheOnExit", current.clearCacheOnExit),
                fakeLocaleLanguage = obj.optString("fakeLocaleLanguage", current.fakeLocaleLanguage)
            )
        } catch (_: Exception) {
            current
        }
    }

    fun deleteCloneProfile(profileId: String) {
        dbHelper.writableDatabase.delete("clone_profiles", "id = ?", arrayOf(profileId))
    }
}
