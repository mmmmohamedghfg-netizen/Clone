package com.appcloner.pro.engine

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.util.Base64
import com.android.apksig.ApkSigner
import com.appcloner.pro.model.CloneConfiguration
import com.appcloner.pro.model.CloneRegistry
import com.appcloner.pro.model.ClonedApkRecord
import com.appcloner.pro.model.DeviceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Security
import java.security.cert.X509Certificate
import java.util.Date
import java.util.UUID
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.cos
import kotlin.math.sin

class ApkClonerEngine(private val context: Context) {

    init {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(BouncyCastleProvider())
        }
    }

    fun isPackageInstalled(packageName: String): Boolean = try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    /**
     * Generates a real preview of the cloned app icon with Hue Shift, Rotation, Flip, and Clone Number Badge.
     */
    fun transformIconBitmap(
        source: Bitmap,
        hueShiftDegrees: Float,
        rotationDegrees: Int,
        flipHorizontal: Boolean,
        showBadge: Boolean,
        badgeText: String
    ): Bitmap {
        val size = source.width.coerceAtLeast(144)
        val scaledSource = Bitmap.createScaledBitmap(source, size, size, true)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)

        val matrix = Matrix()
        if (flipHorizontal) {
            matrix.postScale(-1f, 1f, size / 2f, size / 2f)
        }
        if (rotationDegrees != 0) {
            matrix.postRotate(rotationDegrees.toFloat(), size / 2f, size / 2f)
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (hueShiftDegrees != 0f) {
            paint.colorFilter = ColorMatrixColorFilter(createHueColorMatrix(hueShiftDegrees))
        }

        canvas.drawBitmap(scaledSource, matrix, paint)

        if (showBadge && badgeText.isNotBlank()) {
            val badgeRadius = size * 0.22f
            val cx = size - badgeRadius - (size * 0.04f)
            val cy = size - badgeRadius - (size * 0.04f)

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#00E676")
                style = Paint.Style.FILL
            }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#080D16")
                style = Paint.Style.STROKE
                strokeWidth = size * 0.03f
            }
            canvas.drawCircle(cx, cy, badgeRadius, bgPaint)
            canvas.drawCircle(cx, cy, badgeRadius, borderPaint)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.parseColor("#080D16")
                textSize = badgeRadius * 1.15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            val textOffset = (textPaint.descent() + textPaint.ascent()) / 2
            canvas.drawText(badgeText.take(3), cx, cy - textOffset, textPaint)
        }

        return output
    }

    private fun createHueColorMatrix(hueDegrees: Float): ColorMatrix {
        val angle = (hueDegrees % 360f) * (Math.PI.toFloat() / 180f)
        val cosVal = cos(angle.toDouble()).toFloat()
        val sinVal = sin(angle.toDouble()).toFloat()
        val lumR = 0.213f
        val lumG = 0.715f
        val lumB = 0.072f
        val mat = floatArrayOf(
            lumR + cosVal * (1 - lumR) + sinVal * (-lumR), lumG + cosVal * (-lumG) + sinVal * (-lumG), lumB + cosVal * (-lumB) + sinVal * (1 - lumB), 0f, 0f,
            lumR + cosVal * (-lumR) + sinVal * 0.143f, lumG + cosVal * (1 - lumG) + sinVal * 0.140f, lumB + cosVal * (-lumB) + sinVal * (-0.283f), 0f, 0f,
            lumR + cosVal * (-lumR) + sinVal * (-(1 - lumR)), lumG + cosVal * (-lumG) + sinVal * lumG, lumB + cosVal * (1 - lumB) + sinVal * lumB, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
        return ColorMatrix(mat)
    }

    /**
     * Builds 1..N copies in one run. Every copy gets its own clone number, package name,
     * output file and device identity, and none of them collides with the existing copies
     * in [registry] or with each other.
     */
    suspend fun buildBatchClonedApks(
        baseConfig: CloneConfiguration,
        sourceIcon: Bitmap?,
        registry: CloneRegistry,
        onProgress: (step: String, fraction: Float, logLine: String) -> Unit
    ): Result<List<ClonedApkRecord>> = withContext(Dispatchers.IO) {
        val totalBatch = baseConfig.batchCloneCount.coerceIn(1, 10)
        val createdRecords = mutableListOf<ClonedApkRecord>()
        val originalPkg = baseConfig.originalPackageName

        for (i in 0 until totalBatch) {
            val requestedNum = baseConfig.cloneNumber + i
            val currentCloneNum = CloneNaming.freeCloneNumber(originalPkg, requestedNum, registry)
            registry.numbersFor(originalPkg).add(currentCloneNum)

            val clonedPkg = try {
                CloneNaming.freeClonePackage(originalPkg, currentCloneNum, registry) { pkg ->
                    isPackageInstalled(pkg)
                }
            } catch (e: IllegalStateException) {
                return@withContext Result.failure(e)
            }
            registry.usedPackages.add(clonedPkg)

            val device = DeviceIdentityGenerator.generate(
                seed = DeviceIdentityGenerator.seedForClone(baseConfig.deviceIdentitySeed, i),
                usedIds = registry.usedDeviceIds,
                usedModels = registry.usedDeviceModels
            )
            registry.usedDeviceIds.addAll(listOf(device.serial, device.imei, device.androidId, device.wifiMac))
            registry.usedDeviceModels.add(device.model)

            val hueForThisClone = if (baseConfig.batchAutoColorShift && i > 0) {
                (baseConfig.iconHueShift + i * 48f) % 360f
            } else {
                baseConfig.iconHueShift
            }
            val nameForThisClone = if (totalBatch > 1) {
                "${baseConfig.originalAppName} #$currentCloneNum"
            } else {
                baseConfig.customCloneName
            }
            val badgeForThisClone = if (totalBatch > 1) {
                "$currentCloneNum"
            } else {
                baseConfig.badgeText
            }
            val singleConfig = baseConfig.copy(
                cloneNumber = currentCloneNum,
                customCloneName = nameForThisClone,
                iconHueShift = hueForThisClone,
                badgeText = badgeForThisClone
            )

            val batchPrefix = if (totalBatch > 1) "[نسخة ${i + 1}/$totalBatch] " else ""
            val batchStart = i.toFloat() / totalBatch.toFloat()

            if (currentCloneNum != requestedNum) {
                onProgress(
                    "${batchPrefix}اختيار رقم النسخة...",
                    batchStart,
                    "${batchPrefix}الرقم #$requestedNum مستخدم سابقاً، تم اختيار #$currentCloneNum تلقائياً لتجنب التعارض"
                )
            }
            onProgress(
                "${batchPrefix}هوية الجهاز: ${device.label}",
                batchStart,
                "${batchPrefix}جهاز افتراضي مستقل: ${device.label} | Android ${device.androidRelease} | IMEI ****${device.imei.takeLast(4)}"
            )

            val singleResult = buildSingleClonedApk(
                config = singleConfig,
                clonedPkg = clonedPkg,
                device = device,
                sourceIcon = sourceIcon,
                onProgress = { step, frac, logLine ->
                    val overallFrac = ((i.toFloat() + frac) / totalBatch.toFloat()).coerceIn(0f, 1f)
                    onProgress("$batchPrefix$step", overallFrac, "$batchPrefix$logLine")
                }
            )

            singleResult.fold(
                onSuccess = { rec -> createdRecords.add(rec) },
                onFailure = { err -> return@withContext Result.failure(err) }
            )
        }

        Result.success(createdRecords)
    }

    private fun buildSingleClonedApk(
        config: CloneConfiguration,
        clonedPkg: String,
        device: DeviceProfile,
        sourceIcon: Bitmap?,
        onProgress: (step: String, fraction: Float, logLine: String) -> Unit
    ): Result<ClonedApkRecord> {
        val tempUnsignedFile = File(context.cacheDir, "unsigned_clone_${UUID.randomUUID()}.apk")
        return try {
            val sourceFile = File(config.sourceApkPath)
            if (!sourceFile.exists() || !sourceFile.canRead()) {
                return Result.failure(IllegalStateException("لا يمكن قراءة ملف APK الأصلي: ${config.sourceApkPath}"))
            }

            val outputDir = File(context.filesDir, "cloned_apks").apply { mkdirs() }
            // One file per package: the package name is unique, so the file name is too.
            val finalSignedFile = File(outputDir, "$clonedPkg.apk")
            if (finalSignedFile.exists()) finalSignedFile.delete()

            onProgress(
                "فك حزمة الـ APK الأصلية...",
                0.10f,
                "فتح ${sourceFile.name} (${String.format("%.1f", sourceFile.length() / (1024f * 1024f))} MB)"
            )

            // Prepare custom icon in both PNG and WEBP formats
            var transformedPngBytes: ByteArray? = null
            var transformedWebpBytes: ByteArray? = null
            if (sourceIcon != null) {
                val mutated = transformIconBitmap(
                    source = sourceIcon,
                    hueShiftDegrees = config.iconHueShift,
                    rotationDegrees = config.iconRotationDegrees,
                    flipHorizontal = config.iconFlipHorizontal,
                    showBadge = config.showBadge,
                    badgeText = config.badgeText
                )
                transformedPngBytes = ByteArrayOutputStream().use { bos ->
                    mutated.compress(Bitmap.CompressFormat.PNG, 100, bos)
                    bos.toByteArray()
                }
                transformedWebpBytes = ByteArrayOutputStream().use { bos ->
                    @Suppress("DEPRECATION")
                    val fmt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        Bitmap.CompressFormat.WEBP_LOSSLESS
                    } else {
                        Bitmap.CompressFormat.WEBP
                    }
                    mutated.compress(fmt, 100, bos)
                    bos.toByteArray()
                }
            }

            // Permissions to neutralize
            val permsToDisable = mutableListOf<String>()
            if (config.blockInternetAccess) permsToDisable.add("android.permission.INTERNET")
            if (config.removeCameraPermission) permsToDisable.add("android.permission.CAMERA")
            if (config.removeLocationPermission) {
                permsToDisable.add("android.permission.ACCESS_FINE_LOCATION")
                permsToDisable.add("android.permission.ACCESS_COARSE_LOCATION")
            }
            if (config.removeAudioRecordPermission) permsToDisable.add("android.permission.RECORD_AUDIO")

            val writtenEntryNames = HashSet<String>()
            var maxDexIndex = 1
            val dexNamePattern = Regex("classes\\d*\\.dex")

            ZipFile(sourceFile).use { zipIn ->
                ZipOutputStream(FileOutputStream(tempUnsignedFile)).use { zipOut ->
                    val entries = zipIn.entries().toList()
                    val totalEntries = entries.size.coerceAtLeast(1)

                    entries.forEachIndexed { index, entry ->
                        val name = entry.name

                        // Strip old META-INF signatures
                        if (name.startsWith("META-INF/") &&
                            (name.endsWith(".SF") || name.endsWith(".RSA") || name.endsWith(".DSA") || name.endsWith("MANIFEST.MF"))
                        ) {
                            return@forEachIndexed
                        }

                        // Skip adaptive vector icon XMLs in anydpi-v26 so Android displays our customized raster icon
                        if (config.replaceAdaptiveAndWebpIcons &&
                            name.startsWith("res/mipmap-anydpi") &&
                            (name.endsWith("ic_launcher.xml") || name.endsWith("ic_launcher_round.xml"))
                        ) {
                            onProgress("تحديث الأيقونات المتكيفة (Adaptive Icons)...", 0.25f, "تعطيل القناع المتكيف $name لعرض الأيقونة المعدلة")
                            return@forEachIndexed
                        }

                        // Track highest classesN.dex index for DEX hook injection
                        if (dexNamePattern.matches(name)) {
                            val num = name.removePrefix("classes").removeSuffix(".dex").toIntOrNull() ?: 1
                            if (num > maxDexIndex) maxDexIndex = num
                        }

                        val rawEntryBytes = zipIn.getInputStream(entry).use { it.readBytes() }

                        val isPngLauncher = (name.startsWith("res/mipmap") || name.startsWith("res/drawable")) &&
                            (name.endsWith("ic_launcher.png") || name.endsWith("ic_launcher_round.png") || name.endsWith("ic_launcher_foreground.png"))
                        val isWebpLauncher = config.replaceAdaptiveAndWebpIcons &&
                            (name.startsWith("res/mipmap") || name.startsWith("res/drawable")) &&
                            (name.endsWith("ic_launcher.webp") || name.endsWith("ic_launcher_round.webp") || name.endsWith("ic_launcher_foreground.webp"))

                        val modifiedBytes = when {
                            name == "AndroidManifest.xml" -> {
                                onProgress(
                                    "تعديل AndroidManifest.xml...",
                                    0.30f,
                                    "تغيير الحزمة إلى $clonedPkg وتعديل الصلاحيات"
                                )
                                AxmlBinaryPatcher.patchBinaryManifest(
                                    rawBytes = rawEntryBytes,
                                    oldPackage = config.originalPackageName,
                                    newPackage = clonedPkg,
                                    oldAppLabel = config.originalAppName,
                                    newAppLabel = config.customCloneName,
                                    patchLabel = config.patchArscAppLabel,
                                    neutralizeSplitFlags = config.mergeSplitsIntoStandaloneApk,
                                    permissionsToDisable = permsToDisable
                                )
                            }

                            name == "resources.arsc" && config.patchArscAppLabel -> {
                                onProgress(
                                    "تعديل جدول الموارد resources.arsc...",
                                    0.38f,
                                    "تحديث اسم التطبيق الظاهر إلى (${config.customCloneName})"
                                )
                                AxmlBinaryPatcher.patchResourcesArscLabel(
                                    rawArscBytes = rawEntryBytes,
                                    oldAppLabel = config.originalAppName,
                                    newAppLabel = config.customCloneName
                                )
                            }

                            transformedPngBytes != null && isPngLauncher -> transformedPngBytes
                            transformedWebpBytes != null && isWebpLauncher -> transformedWebpBytes
                            else -> rawEntryBytes
                        }

                        writeZipEntryAligned(zipOut, name, modifiedBytes, entry.method)
                        writtenEntryNames.add(name)

                        if (index % 180 == 0) {
                            val frac = 0.15f + (0.35f * (index.toFloat() / totalEntries))
                            onProgress("معالجة ملفات الحزمة (${index + 1}/$totalEntries)...", frac, "تمت معالجة: $name")
                        }
                    }

                    // Step 2B: Merge Split APKs (App Bundles) if present & enabled
                    var mergedSplitsCount = 0
                    if (config.mergeSplitsIntoStandaloneApk && config.splitApkPaths.isNotEmpty()) {
                        config.splitApkPaths.forEachIndexed { sIdx, splitPath ->
                            val splitFile = File(splitPath)
                            if (splitFile.exists() && splitFile.canRead()) {
                                mergedSplitsCount++
                                onProgress(
                                    "دمج الحزم المقسمة Split APKs (${sIdx + 1}/${config.splitApkPaths.size})...",
                                    0.58f,
                                    "دمج ملفات ومكتبات: ${splitFile.name}"
                                )
                                ZipFile(splitFile).use { splitZip ->
                                    for (splitEntry in splitZip.entries()) {
                                        val sName = splitEntry.name
                                        if (sName == "AndroidManifest.xml" ||
                                            sName == "resources.arsc" ||
                                            sName.startsWith("META-INF/")
                                        ) {
                                            continue
                                        }
                                        // Copy native libraries (.so), assets, and non-conflicting resources
                                        if (!writtenEntryNames.contains(sName)) {
                                            val sBytes = splitZip.getInputStream(splitEntry).use { it.readBytes() }
                                            writeZipEntryAligned(zipOut, sName, sBytes, splitEntry.method)
                                            writtenEntryNames.add(sName)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Step 3: Inject Executable DEX Hook (classesN.dex)
                    if (config.injectDexRuntimeHook) {
                        val hookDexName = "classes${maxDexIndex + 1}.dex"
                        onProgress(
                            "حقن محرك التمويه التنفيذي ($hookDexName)...",
                            0.68f,
                            "توليد وحقن ملف Dalvik DEX Hook ($hookDexName) لتفعيل التمويه والقفل والبروكسي"
                        )
                        val dexBytes = DexHookGenerator.generateRuntimeHookDex(config, clonedPkg)
                        writeZipEntryAligned(zipOut, hookDexName, dexBytes, ZipEntry.DEFLATED)
                        writtenEntryNames.add(hookDexName)
                    }

                    // Step 4: Inject Original Signature Binary for Signature Verification Bypass
                    if (config.spoofOriginalSignature && config.originalSignatureBase64.isNotBlank()) {
                        onProgress(
                            "حقن البصمة الأصلية لتخطي فحص التوقيع...",
                            0.74f,
                            "حفظ التوقيع الأصلي SHA-256 (${config.originalSignatureSha256.take(18)}...) داخل assets/app_cloner_orig_sig.bin"
                        )
                        val rawSig = runCatching {
                            Base64.decode(config.originalSignatureBase64, Base64.DEFAULT)
                        }.getOrDefault(config.originalSignatureBase64.toByteArray())
                        writeZipEntryAligned(zipOut, "assets/app_cloner_orig_sig.bin", rawSig, ZipEntry.DEFLATED)
                    }

                    // Step 5: Inject the virtual device identity and runtime configuration
                    onProgress(
                        "حقن هوية الجهاز المستقلة والإعدادات...",
                        0.80f,
                        "جهاز ${device.label} | ${device.brand} ${device.model} | Android ${device.androidRelease}"
                    )
                    val clonerConfigJson = buildSpoofingConfigJson(config, clonedPkg, device, mergedSplitsCount)
                    writeZipEntryAligned(
                        zipOut,
                        "assets/app_cloner_config.json",
                        clonerConfigJson.toByteArray(Charsets.UTF_8),
                        ZipEntry.DEFLATED
                    )
                }
            }

            // Step 6: Sign the cloned APK with V1 + V2 signatures using Google apksig
            onProgress(
                "توقيع الـ APK بشهادة رقمية (V1 + V2 Signing)...",
                0.90f,
                "توليد شهادة RSA-2048 وتوقيع الحزمة عبر محرك Google apksig..."
            )
            signApkWithV1AndV2(tempUnsignedFile, finalSignedFile)

            val finalSizeMb = finalSignedFile.length().toFloat() / (1024f * 1024f)
            onProgress(
                "اكتمل بناء وتوقيع النسخة بنجاح!",
                1.0f,
                "النسخة جاهزة: ${finalSignedFile.name} (${String.format("%.2f", finalSizeMb)} MB)"
            )

            val record = ClonedApkRecord(
                id = UUID.randomUUID().toString(),
                originalAppName = config.originalAppName,
                clonedAppName = config.customCloneName,
                originalPackage = config.originalPackageName,
                clonedPackage = clonedPkg,
                cloneNumber = config.cloneNumber,
                apkFilePath = finalSignedFile.absolutePath,
                fileSizeMb = finalSizeMb,
                mergedSplitsCount = if (config.mergeSplitsIntoStandaloneApk) config.splitApkPaths.size else 0,
                stealthModeLabel = config.stealthLockMode.labelAr,
                deviceLabel = device.label,
                deviceProfileJson = device.toJson(),
                createdAt = System.currentTimeMillis()
            )
            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            tempUnsignedFile.delete()
        }
    }

    private fun writeZipEntryAligned(
        zipOut: ZipOutputStream,
        name: String,
        bytes: ByteArray,
        originalMethod: Int
    ) {
        val newEntry = ZipEntry(name)
        if (originalMethod == ZipEntry.STORED || name == "resources.arsc" || name.endsWith(".so")) {
            newEntry.method = ZipEntry.STORED
            newEntry.size = bytes.size.toLong()
            newEntry.compressedSize = bytes.size.toLong()
            val crc = CRC32()
            crc.update(bytes)
            newEntry.crc = crc.value
        } else {
            newEntry.method = ZipEntry.DEFLATED
        }
        zipOut.putNextEntry(newEntry)
        zipOut.write(bytes)
        zipOut.closeEntry()
    }

    private fun buildSpoofingConfigJson(
        config: CloneConfiguration,
        clonedPkg: String,
        device: DeviceProfile,
        mergedSplitsCount: Int
    ): String {
        return JSONObject().apply {
            put("cloner_engine", "AppClonerPro v2.1 Ultimate")
            put("original_package", config.originalPackageName)
            put("cloned_package", clonedPkg)
            put("clone_name", config.customCloneName)
            put("clone_number", config.cloneNumber)
            put("dex_hook_injected", config.injectDexRuntimeHook)
            put("merged_splits_count", mergedSplitsCount)
            put("spoof_original_signature", config.spoofOriginalSignature)
            put("original_signature_sha256", config.originalSignatureSha256)
            put("spoof_android_id", if (config.spoofAndroidId) device.androidId else "system")
            put("spoof_imei", if (config.spoofImeiAndSerial) device.imei else "system")
            put("spoof_serial", if (config.spoofImeiAndSerial) device.serial else "system")
            put("spoof_wifi_mac", if (config.spoofWifiMacAddress) device.wifiMac else "system")
            put("hide_sim_operator", config.hideSimOperatorInfo)
            put("carrier_name", if (config.hideSimOperatorInfo) "" else device.carrierName)
            put("timezone", device.timezone)
            put("device_profile", JSONObject(device.toJson()))
            put("disable_screenshots", config.disableScreenshots)
            put("incognito_keyboard", config.incognitoKeyboard)
            put("stealth_lock_mode", config.stealthLockMode.id)
            put("lock_pin_sha256", sha256Hex(config.lockPinCode))
            put("proxy_enabled", config.enableProxy)
            if (config.enableProxy) {
                put("proxy_protocol", config.proxyProtocol.id)
                put("proxy_host", config.proxyHost)
                put("proxy_port", config.proxyPort)
                put("proxy_username", config.proxyUsername)
                put("proxy_password", config.proxyPassword)
            }
            put("clear_cache_on_exit", config.clearCacheOnExit)
            put("force_locale", config.fakeLocaleLanguage)
            put("timestamp", System.currentTimeMillis())
        }.toString(2)
    }

    private fun sha256Hex(input: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun signApkWithV1AndV2(unsignedApk: File, signedApk: File) {
        // A fresh key per copy: each copy is its own app and never needs to update another copy.
        val (privateKey, cert) = generateSigningCredentials()
        val signerConfig = ApkSigner.SignerConfig.Builder(
            "AppClonerProKey",
            privateKey,
            listOf(cert)
        ).build()

        val apkSigner = ApkSigner.Builder(listOf(signerConfig))
            .setInputApk(unsignedApk)
            .setOutputApk(signedApk)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(false)
            .setMinSdkVersion(24)
            .build()

        apkSigner.sign()
    }

    private fun generateSigningCredentials(): Pair<PrivateKey, X509Certificate> {
        val keyGen = KeyPairGenerator.getInstance("RSA")
        keyGen.initialize(2048)
        val keyPair = keyGen.generateKeyPair()

        val issuer = X500Name("CN=AppClonerPro, OU=MobileSecurity, O=AppCloner, C=EG")
        val serial = BigInteger(64, java.security.SecureRandom())
        val notBefore = Date(System.currentTimeMillis() - 86400_000L)
        val notAfter = Date(System.currentTimeMillis() + 25L * 365 * 86400_000L)

        val certBuilder = JcaX509v3CertificateBuilder(
            issuer,
            serial,
            notBefore,
            notAfter,
            issuer,
            keyPair.public
        )

        val contentSigner = JcaContentSignerBuilder("SHA256WithRSA")
            .build(keyPair.private)

        val cert = JcaX509CertificateConverter()
            .getCertificate(certBuilder.build(contentSigner))

        return keyPair.private to cert
    }
}
