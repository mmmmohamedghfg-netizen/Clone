package com.appcloner.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import com.appcloner.pro.ui.AppClonerScreen
import com.appcloner.pro.viewmodel.ClonerViewModel

class MainActivity : ComponentActivity() {

    private val clonerViewModel: ClonerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppClonerScreen(viewModel = clonerViewModel)
            }
        }
    }
}
