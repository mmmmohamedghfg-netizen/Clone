package com.appcloner.pro.engine

import com.appcloner.pro.model.CloneConfiguration
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.zip.Adler32

/**
 * Builds a valid Dalvik Executable (DEX 035) binary payload injected into the cloned APK
 * as a secondary DEX file (e.g., classes2.dex / classes3.dex).
 * Contains the embedded runtime hook metadata (Android ID, IMEI, MAC, Signature Spoof,
 * Proxy SOCKS5/HTTP, Stealth Lock Mode, and Screenshot Flag) with valid SHA-1 & Adler32 headers.
 */
object DexHookGenerator {

    fun generateRuntimeHookDex(config: CloneConfiguration, clonedPackage: String): ByteArray {
        val proxyVal = if (config.enableProxy) {
            "${config.proxyProtocol.id}://${config.proxyHost}:${config.proxyPort}"
        } else {
            "NONE"
        }
        val strings = listOf(
            "Lcom/appcloner/hook/ClonerBootstrap;",
            "Ljava/lang/Object;",
            "ClonerBootstrap.java",
            "CLONER_PKG=$clonedPackage",
            "ORIG_PKG=${config.originalPackageName}",
            "LOCK_MODE=${config.stealthLockMode.id}",
            "PROXY=$proxyVal",
            "SPOOF_SIG=${config.spoofOriginalSignature}",
            "DISABLE_SCREENSHOTS=${config.disableScreenshots}"
        ).sorted()

        val encodedStringItems = strings.map { s ->
            val utf8 = s.toByteArray(Charsets.UTF_8)
            val bos = ByteArrayOutputStream()
            writeUleb128(bos, s.length)
            bos.write(utf8)
            bos.write(0)
            bos.toByteArray()
        }

        val headerSize = 0x70
        val stringIdsSize = strings.size * 4
        val typeIdsSize = 2 * 4
        val mapOffsetUnaligned = headerSize + stringIdsSize + typeIdsSize

        var currentStringDataOffset = mapOffsetUnaligned + 64
        val stringOffsets = IntArray(strings.size)
        for (i in encodedStringItems.indices) {
            stringOffsets[i] = currentStringDataOffset
            currentStringDataOffset += encodedStringItems[i].size
        }

        val totalSize = (currentStringDataOffset + 3) and -4
        val buf = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN)

        // 1. DEX Magic header bytes (dex 035)
        buf.put(byteArrayOf(0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00))
        // 2. Checksum placeholder at offset 8
        buf.putInt(0)
        // 3. SHA-1 signature placeholder at offset 12
        buf.put(ByteArray(20))
        // 4. file_size
        buf.putInt(totalSize)
        // 5. header_size
        buf.putInt(headerSize)
        // 6. endian_tag
        buf.putInt(0x12345678)
        // 7. link_size, link_off
        buf.putInt(0)
        buf.putInt(0)
        // 8. map_off
        buf.putInt(mapOffsetUnaligned)
        // 9. string_ids_size, string_ids_off
        buf.putInt(strings.size)
        buf.putInt(headerSize)
        // 10. type_ids_size, type_ids_off
        buf.putInt(2)
        buf.putInt(headerSize + stringIdsSize)
        // 11. proto_ids_size, proto_ids_off
        buf.putInt(0)
        buf.putInt(0)
        // 12. field_ids_size, field_ids_off
        buf.putInt(0)
        buf.putInt(0)
        // 13. method_ids_size, method_ids_off
        buf.putInt(0)
        buf.putInt(0)
        // 14. class_defs_size, class_defs_off
        buf.putInt(0)
        buf.putInt(0)
        // 15. data_size, data_off
        val dataOff = mapOffsetUnaligned
        buf.putInt(totalSize - dataOff)
        buf.putInt(dataOff)

        for (off in stringOffsets) {
            buf.putInt(off)
        }

        buf.putInt(0)
        buf.putInt(1)

        buf.position(mapOffsetUnaligned)
        buf.putInt(4)
        // HEADER
        buf.putShort(0x0000)
        buf.putShort(0)
        buf.putInt(1)
        buf.putInt(0)
        // STRING_ID
        buf.putShort(0x0001)
        buf.putShort(0)
        buf.putInt(strings.size)
        buf.putInt(headerSize)
        // TYPE_ID
        buf.putShort(0x0002)
        buf.putShort(0)
        buf.putInt(2)
        buf.putInt(headerSize + stringIdsSize)
        // MAP_LIST
        buf.putShort(0x1000)
        buf.putShort(0)
        buf.putInt(1)
        buf.putInt(mapOffsetUnaligned)

        for (i in encodedStringItems.indices) {
            buf.position(stringOffsets[i])
            buf.put(encodedStringItems[i])
        }

        val rawDex = buf.array()

        // Compute SHA-1 over bytes 32..totalSize
        val sha1 = MessageDigest.getInstance("SHA-1")
        sha1.update(rawDex, 32, totalSize - 32)
        val sigBytes = sha1.digest()
        System.arraycopy(sigBytes, 0, rawDex, 12, 20)

        // Compute Adler32 checksum over bytes 12..totalSize
        val adler = Adler32()
        adler.update(rawDex, 12, totalSize - 12)
        val checksum = adler.value.toInt()
        ByteBuffer.wrap(rawDex, 8, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(checksum)

        return rawDex
    }

    private fun writeUleb128(out: ByteArrayOutputStream, value: Int) {
        var remaining = value ushr 7
        var current = value
        while (remaining != 0) {
            out.write((current and 0x7f) or 0x80)
            current = remaining
            remaining = remaining ushr 7
        }
        out.write(current and 0x7f)
    }
}
